package com.student.age.service;

import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Student;
import com.student.age.model.vo.request.StudentRequestVO;
import com.student.age.model.vo.request.StudentSearchCriteriaRequestVO;
import com.student.age.model.vo.response.StudentResponseVO;
import com.student.age.model.vo.response.StudentSearchCriteriaResponseVO;
import com.student.age.model.vo.response.StudentWithParentResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface IStudentService {
    //API Methods-> Entity to Response
    StudentResponseVO add(Long parentId,StudentRequestVO vo);
    StudentResponseVO update(Long id, StudentRequestVO vo);
    StudentResponseVO getById(Long id);
    void deleteById(Long id);
    List<StudentResponseVO> getAll();
    List<StudentResponseVO> getStudentsAboveAge(int age);
    List<StudentResponseVO> getStudentsByNamePrefix(String prefix);
    List<StudentResponseVO> findByAge(Integer age);
    Page<StudentWithParentResponse> findStudentsByCriteria(Integer age, String gender, AccountStatus parentStatus, int page,int size,String sortBy,String direction);
    List<StudentSearchCriteriaResponseVO> advanceSearchStudents(StudentSearchCriteriaRequestVO criteria);
    byte[]generateStudentReport(StudentSearchCriteriaRequestVO criteria);


    //INTERNAL Methods-> Request to entity
    Student createStudentEntity(StudentRequestVO vo);
    Student updateStudentEntity(Long studentId, StudentRequestVO vo);
}
