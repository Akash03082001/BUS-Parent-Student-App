package com.student.age.controller;

import com.student.age.helper.converter.ParentConverter;
import com.student.age.helper.fetcher.AuthContext;
import com.student.age.helper.fetcher.ParentFetcher;
import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Parent;
import com.student.age.model.vo.request.ChangePasswordRequestVO;
import com.student.age.model.vo.request.ParentRequestVO;
import com.student.age.model.vo.request.ParentUpdateRequestVO;
import com.student.age.model.vo.request.StudentRequestVO;
import com.student.age.model.vo.response.ParentResponseVO;
import com.student.age.model.vo.response.StudentResponseVO;
import com.student.age.service.IParentService;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

//for using lombok
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/parents")
public class ParentController {

    @Autowired
    private IParentService parentService;

    @Autowired
    private ParentFetcher parentFetcher;

    @Autowired
    private AuthContext authContext; //to get parentID during login

     //  ✅ Parent APIs

    @PostMapping
    public ParentResponseVO add(@Valid @RequestBody ParentRequestVO vo){
        return parentService.add(vo);
    }

    @PostMapping("/{id}")
    public ParentResponseVO update(@PathVariable Long id, @Valid @RequestBody ParentUpdateRequestVO vo){
        return parentService.update(id,vo);
    }

    @DeleteMapping("/{id}")
    public String deleteById(@PathVariable Long id){
        parentService.deleteById(id);
        return "Parent deleted successfully";
    }

    @GetMapping("/{id}")
    public ParentResponseVO getById(@PathVariable Long id,
                                    HttpServletRequest request){
        Long loggedInParentId = authContext.getLoggedInParentId(request);
        if (!loggedInParentId.equals(id)) {
            throw new ResponseStatusException(
                    HttpStatus.FORBIDDEN, "Access denied");
        }
        return parentService.getById(id);
    }

    @PostMapping("/{id}/change-password")
    public String changePassword(@PathVariable Long id,@Valid @RequestBody ChangePasswordRequestVO vo){
        parentService.changePassword(id, vo);
        return "Password changed successfully";
    }

    @GetMapping
    public List<ParentResponseVO> getAll(){

        return parentService.getAll();
    }

    //✅ Child APIs (Parent‑Scoped)

    @PostMapping("/{parentId}/students")
    public StudentResponseVO addChildToParent(@PathVariable Long parentId,@Valid @RequestBody StudentRequestVO vo){
        return parentService.addChildToParent(parentId, vo);
    }

    @PostMapping("/{parentId}/students/{childId}")
    public StudentResponseVO updateChildFromParent(@PathVariable Long parentId,@PathVariable Long childId,@RequestBody StudentRequestVO vo){
        return parentService.updateChildFromParent(parentId, childId, vo);
    }

    @DeleteMapping("/{parentId}/students/{childId}")
    public String deleteChildFromParent(@PathVariable Long parentId,@PathVariable Long childId){
        parentService.deleteChildFromParent(parentId, childId);
        return "Student deleted successfully";
    }

    @GetMapping("/search")
    public List<ParentResponseVO> searchParents(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) AccountStatus status,
            @RequestParam(defaultValue = "email")String sortBy,
            @RequestParam(defaultValue = "asc")String sortDir) {


        log.info(
                "Searching parents with name={}, email={}, status={}, sortBy={}, sortDir={}",
                name, email, status, sortBy, sortDir
        );


        List<ParentResponseVO> parents =
                parentService.searchParents(name, email, status, sortBy, sortDir);

        log.info("Total parents found: {}", parents.size());

        return parents;

    }

    @GetMapping("/students/gender")
    public Page<ParentResponseVO> getByGender(@RequestParam String gender,
                                              @RequestParam(defaultValue = "0") int page,
                                              @RequestParam(defaultValue = "5") int size,
                                              @RequestParam(defaultValue = "name") String sortBy,
                                              @RequestParam(defaultValue = "asc") String direction){
        return parentService.findByGender(gender,page,size,sortBy,direction);
    }


}
