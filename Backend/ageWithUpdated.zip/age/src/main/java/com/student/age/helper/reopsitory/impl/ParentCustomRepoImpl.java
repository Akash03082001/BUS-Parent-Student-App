package com.student.age.helper.reopsitory.impl;

import com.student.age.helper.reopsitory.ParentCustomRepo;
import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Parent;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
@Repository
public class ParentCustomRepoImpl implements ParentCustomRepo {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<Parent> searchParents(String nameHash, String email, AccountStatus status,
                                      String sortBy,String sortDir) {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Parent> cq = cb.createQuery(Parent.class);
        Root<Parent> parent = cq.from(Parent.class);
        List<Predicate> predicates = new ArrayList<>();

        // ✅ name filter (optional)
        if(nameHash!=null && !nameHash.isBlank()){
           predicates.add(cb.equal(parent.get("nameHash"),nameHash));
        }


        // ✅ email filter (optional)
        if (email != null && !email.isBlank()) {
            predicates.add(
                    cb.like(
                            cb.lower(parent.get("email")),
                            "%" + email.toLowerCase() + "%"
                    )
            );
        }

        // ✅ status filter (optional)
        if (status != null) {
            predicates.add(
                    cb.equal(parent.get("status"), status)
            );
        }

        cq.where(cb.and(predicates.toArray(new Predicate[0])));

        // Sorting
        String sortField = switch (sortBy){
            case "email"->"email";
            case "status"->"status";
            case "name"->"searchName";
            case "id"->"id";
            default -> "email";
        };

        //Sort Direction
        if("desc".equalsIgnoreCase(sortDir)){
            cq.orderBy(cb.desc(parent.get(sortField)));
        }else{
            cq.orderBy(cb.asc(parent.get(sortField)));
        }

        return entityManager.createQuery(cq).getResultList();
    }
}
