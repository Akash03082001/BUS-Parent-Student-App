package com.student.age.controller.frontEnd;

import com.student.age.config.CryptoUtil;
import com.student.age.config.JwtUtil;
import com.student.age.exception.ResourceNotFoundException;
import com.student.age.helper.reopsitory.ParentRepo;
import com.student.age.model.frontend.LoginRequestVO;
import com.student.age.model.frontend.LoginResponseVO;
import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Parent;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
public class LoginController {

    private final ParentRepo parentRepo;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final CryptoUtil cryptoUtil;

    @PostMapping("/login")
    public LoginResponseVO login(@RequestBody LoginRequestVO request) {

        Parent parent = parentRepo.findByEmail(request.getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("Invalid credentials"));

        if (!passwordEncoder.matches(request.getPassword(), parent.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        if (parent.getStatus() != AccountStatus.ACTIVE) {
            throw new RuntimeException("Account inactive");
        }

        String token = jwtUtil.generateToken(parent.getId(), parent.getEmail());

        return new LoginResponseVO(
                parent.getId(),
                cryptoUtil.decrypt(parent.getNameEnc()), // ✅ decrypt here
                parent.getEmail(),
                parent.getStatus(),
                token
        );
    }
}



//    @Autowired
//    private ParentRepo parentRepo;
//👉 This won’t work because:
//final fields must be initialized at the time of object creation
//Field injection (@Autowired on fields) happens after the object is created
//So Spring has no chance to assign a value to a final field later → ❌ compilation error
//    Use a constructor instead:
//    Constructor runs during object creation
//    final fields get initialized immediately
//    Spring passes the dependency into the constructor