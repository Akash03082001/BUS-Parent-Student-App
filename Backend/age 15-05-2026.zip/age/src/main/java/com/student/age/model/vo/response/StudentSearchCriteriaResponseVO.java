package com.student.age.model.vo.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor

public class StudentSearchCriteriaResponseVO {

    private Long id;
    private String name;
    private Integer age;
    private String gender;
    private LocalDate dateOfBirth;
    private String ageGroup;

    // Parent info (flattened)
    private Long parentId;
    private String parentName;

}
