package com.student.age.helper.reopsitory;

import com.student.age.model.entity.Admin;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface AdminRepo extends JpaRepository<Admin,Long> {
    Optional<Admin> findByAdminName(String adminName);
    Optional<Admin> findByAdminEmail(String adminEmail);
}
