package com.student.age.controller;

import com.student.age.helper.store.ReportStore;
import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Student;
import com.student.age.model.vo.request.StudentRequestVO;
import com.student.age.model.vo.request.StudentSearchCriteriaRequestVO;
import com.student.age.model.vo.response.StudentResponseVO;
import com.student.age.model.vo.response.StudentSearchCriteriaResponseVO;
import com.student.age.model.vo.response.StudentWithParentResponse;
import com.student.age.service.imp.StudentServiceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentServiceImp studentService;

    @Autowired
    private ReportStore reportStore;

    @PostMapping("parentId/{parentId}")
    public StudentResponseVO add(@PathVariable Long parentId,@RequestBody StudentRequestVO vo){
        return studentService.add(parentId,vo);
    }

    @PutMapping("/{id}")
    public StudentResponseVO update(@PathVariable Long id,@RequestBody StudentRequestVO vo){
        return studentService.update(id,vo);
    }

    @GetMapping("/{id}")
    public StudentResponseVO getById(@PathVariable Long id){
        return studentService.getById(id);
    }

    @DeleteMapping("/{id}")
    public String deleteById(@PathVariable Long id){
        studentService.deleteById(id);
        return "Deleted Successfully";
    }

    @GetMapping
    public List<StudentResponseVO> getAll(){
        return studentService.getAll();
    }

    @GetMapping("/age/above")
    public List<StudentResponseVO> getStudentsAboveAge(
            @RequestParam int age) {
        return studentService.getStudentsAboveAge(age);
    }

    @GetMapping("/name/starts-with")
    public List<StudentResponseVO> getStudentsByNamePrefix(
            @RequestParam String prefix) {

        return studentService.getStudentsByNamePrefix(prefix);
    }

    @GetMapping("/getByAge")
    public List<StudentResponseVO> getByAge(@RequestParam Integer age){
        return studentService.findByAge(age);
    }

    @GetMapping("/search")
    public Page<StudentWithParentResponse> findStudentsByCriteria(@RequestParam(required = false) Integer age,
                                                                  @RequestParam(required = false) String gender,
                                                                  @RequestParam(required = false)AccountStatus parentStatus,
                                                                  @RequestParam(defaultValue = "0") int page,
                                                                  @RequestParam(defaultValue = "5") int size,
                                                                  @RequestParam(defaultValue = "id") String sortBy,
                                                                  @RequestParam(defaultValue = "asc")String direction){
        return studentService.findStudentsByCriteria(age, gender,parentStatus,page,size,sortBy,direction);
    }

    @PostMapping("/advanceSearch")
    public Page<StudentSearchCriteriaResponseVO> advanceSearchStudents(@RequestBody StudentSearchCriteriaRequestVO criteria,
                                                                       @RequestParam(defaultValue = "0") int page,
                                                                       @RequestParam(defaultValue = "10") int size,
                                                                       @RequestParam(defaultValue = "id,asc")String sort
    ){
        Pageable pageable = PageRequest.of(page,size, Sort.by(sort));
        return studentService.advanceSearchStudents(criteria,pageable);
    }

        //used for viewing and downloading in postman
    @PostMapping(
            value = "/advanceSearch/report",
            produces = "application/pdf"
    )
    public ResponseEntity<byte[]> downloadStudentReport(
            @RequestBody StudentSearchCriteriaRequestVO criteria) {

        byte[] pdf = studentService.generateStudentReport(criteria);

        return ResponseEntity.ok()
                .header("Content-Disposition",
                        "attachment; filename=student-report.pdf")
                .body(pdf);
    }

    //use inline to directly open on browser only when working with browser
    //use attachment to view in postman



    //using URL:
    @PostMapping("/advanceSearch/report/generate")
    public ResponseEntity<Map<String, String>> generateReport(
            @RequestBody StudentSearchCriteriaRequestVO criteria) {

        byte[] pdf = studentService.generateStudentReport(criteria);
        String reportId = reportStore.save(pdf);

        String downloadUrl =
                "http://localhost:8080/students/advanceSearch/report/download/" + reportId;

        return ResponseEntity.ok(
                Map.of("downloadUrl", downloadUrl)
        );
    }

        // autoDownload endpoint, no need to create response in postman
    //it is used only for auto download
    @GetMapping(
            value = "/advanceSearch/report/download/{reportId}",
            produces = MediaType.APPLICATION_PDF_VALUE
    )
    public ResponseEntity<byte[]> downloadReport(
            @PathVariable String reportId) {

        byte[] pdf = reportStore.get(reportId);

        if (pdf == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok()
                .header("Content-Disposition",
                        "attachment; filename=student-report.pdf")
                .body(pdf);
    }


}
