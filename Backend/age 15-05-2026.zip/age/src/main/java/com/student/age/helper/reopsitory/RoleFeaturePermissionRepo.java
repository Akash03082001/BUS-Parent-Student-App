package com.student.age.helper.reopsitory;

import com.student.age.model.entity.RoleFeaturePermission;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleFeaturePermissionRepo extends JpaRepository<RoleFeaturePermission,Long> {

    //to check permission
    boolean existsByRoleAndFeatureAndPermissionTrue(String role,String feature);
}
