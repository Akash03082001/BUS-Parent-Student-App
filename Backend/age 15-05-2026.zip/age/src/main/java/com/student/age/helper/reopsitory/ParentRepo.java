package com.student.age.helper.reopsitory;

import com.student.age.helper.reopsitory.impl.ParentCustomRepoImpl;
import com.student.age.model.entity.Parent;
import com.student.age.model.entity.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface ParentRepo extends JpaRepository<Parent,Long>, ParentCustomRepo {
    Page<Parent> findDistinctByStudentsGenderIgnoreCase(String gender, Pageable pageable);
    Optional<Parent> findByEmail(String email);

    @Query("SELECT COUNT(p) FROM Parent p WHERE SIZE (p.students) > 0")
    Long countParentWithStudents();

}
