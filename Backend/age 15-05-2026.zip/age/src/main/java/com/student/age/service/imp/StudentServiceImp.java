package com.student.age.service.imp;

import com.student.age.helper.converter.StudentConverter;
import com.student.age.helper.fetcher.AgeFetcher;
import com.student.age.helper.fetcher.ParentFetcher;
import com.student.age.helper.fetcher.StudentFetcher;
import com.student.age.helper.reopsitory.StudentRepo;
import com.student.age.helper.report.StudentPdfReportGenerator;
import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Age;
import com.student.age.model.entity.Parent;
import com.student.age.model.entity.Student;
import com.student.age.model.frontend.ViewStudentResponse;
import com.student.age.model.vo.request.StudentRequestVO;
import com.student.age.model.vo.request.StudentSearchCriteriaRequestVO;
import com.student.age.model.vo.response.StudentResponseVO;
import com.student.age.model.vo.response.StudentSearchCriteriaResponseVO;
import com.student.age.model.vo.response.StudentWithParentResponse;
import com.student.age.service.IStudentService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Set;

@Service
@Transactional
public class StudentServiceImp implements IStudentService {


    @Autowired
    private StudentRepo studentRepo;

    @Autowired
    private StudentFetcher studentFetcher;

    @Autowired
    private StudentConverter studentConverter;

    @Autowired
    private AgeFetcher ageFetcher;

    @Autowired
    private ParentFetcher parentFetcher;

    @Override //can store student only when parent is created
    public StudentResponseVO add(Long parentId, StudentRequestVO vo) {
        Parent parent = parentFetcher.getById(parentId);
        Student student = createStudentEntity(vo);
        student.setParent(parent);
        return studentConverter.toResponse(studentRepo.save(student));
    }

    @Override
    public StudentResponseVO update(Long id, StudentRequestVO vo) {

        // 1️⃣ Fetch existing student
        Student student = studentFetcher.getById(id);

        // 2️⃣ Update name only if provided
        if (vo.getName() != null && !vo.getName().isBlank()) {
            student.setName(vo.getName());
        }

        // 3️⃣ Update gender only if provided
        if (vo.getGender() != null && !vo.getGender().isBlank()) {
            student.setGender(vo.getGender());
        }

        // 4️⃣ Update DOB only if provided
        if (vo.getDateOfBirth() != null) {

            student.setDateOfBirth(vo.getDateOfBirth());

            // ✅ Calculate age from DOB (SOURCE OF TRUTH)
            int calculatedAge = java.time.Period.between(
                    vo.getDateOfBirth(),
                    java.time.LocalDate.now()
            ).getYears();

            // ✅ Validate age range (0–24)
            if (calculatedAge < 0 || calculatedAge > 24) {
                throw new IllegalArgumentException(
                        "Age must be between 0 and 24 years"
                );
            }

            // ✅ Set calculated age
            student.setAge(calculatedAge);

            // ✅ Re-map age group using calculated age
            Age ageGroup = ageFetcher.getByAge(calculatedAge);
            student.setAgeDetails(ageGroup);
        }

        // 5️⃣ Save and return response
        return studentConverter.toResponse(
                studentRepo.save(student)
        );

    }

    @Override
    public StudentResponseVO getById(Long id) {
        return studentConverter.toResponse(
                studentFetcher.getById(id)
        );
    }

    @Override
    public void deleteById(Long id) {
        Student student=studentFetcher.getById(id);
//        student.setStatus(AccountStatus.DELETED);
        studentRepo.delete(student);
    }

    @Override
    public List<StudentResponseVO> getAll() {
        return studentRepo.findAll()
                .stream()
                .map(studentConverter::toResponse)
                .toList();
    }

    @Override
    public List<StudentResponseVO> getStudentsAboveAge(int age) {
        List<Student> students=studentRepo.findByAgeGreaterThan(age);
        if(students.isEmpty()){
            throw new IllegalStateException("No student found with the age above: "+age);
        }
        return studentRepo.findByAgeGreaterThan(age)
                .stream()
                .map(studentConverter::toResponse)
                .toList();
    }

    @Override
    public List<StudentResponseVO> getStudentsByNamePrefix(String prefix) {
        List<Student> students=studentRepo.findStudentsByNamePrefix(prefix);
        if(students.isEmpty()){
            throw new IllegalStateException("No student found with prefix: "+prefix);
        }

        return studentRepo.findStudentsByNamePrefix(prefix)
                .stream()
                .map(studentConverter::toResponse)
                .toList();

    }

    @Override
    public List<StudentResponseVO> findByAge(Integer age) {
        List<Student> students=studentRepo.findByAge(age);
        if(students.isEmpty()){
            throw new IllegalStateException("No student found with age: "+age);
        }
        return studentRepo.findByAge(age)
                .stream()
                .map(studentConverter::toResponse)
                .toList();
    }

    @Override
    public Page<StudentWithParentResponse> findStudentsByCriteria(Integer age, String gender, AccountStatus parentStatus, int page,int size,String sortBy,String direction) {
        Set<String> allowedSorts = Set.of("id","name");

        // Default fallback
        String finalSort = allowedSorts.contains(sortBy) ? sortBy : "id";
        Sort.Direction sortDirection = "desc".equalsIgnoreCase(direction)
                ?Sort.Direction.DESC
                :Sort.Direction.ASC;

        Pageable pageable = PageRequest.of(page,size, Sort.by(sortDirection,finalSort));
        return  studentRepo.findStudentsByCriteria(
                age, gender, parentStatus,pageable
        );
    }



    @Override
    public Page<StudentSearchCriteriaResponseVO> advanceSearchStudents(StudentSearchCriteriaRequestVO criteria,Pageable pageable) {
        return studentRepo.searchStudents(criteria,pageable);
    }

    @Override
    public byte[] generateStudentReport(StudentSearchCriteriaRequestVO criteria) {
            List<StudentSearchCriteriaResponseVO> students =
                    studentRepo.searchStudents(criteria);
            return StudentPdfReportGenerator.generateReport(students);
    }

    @Override
    public Page<ViewStudentResponse> getStudentsForParent(Long parentId,String searchText ,Pageable pageable) {

        Page<Student> page = studentRepo.findByParentIdWithAgeGroup(parentId, searchText,pageable);

        return page.map(s -> new ViewStudentResponse(
                s.getId(),
                s.getName(),
                s.getGender(),
                s.getAge(),
                s.getDateOfBirth(),
                s.getAgeDetails().getLabel()
        ));

    }
    /*---------------------------------------------------------------------------------------------------------------*/

    @Override
    public Student createStudentEntity(StudentRequestVO vo) {

        Student student = studentConverter.toEntity(vo);

        int age = Period.between(
                vo.getDateOfBirth(),
                LocalDate.now()
        ).getYears();

        if (age < 0 || age > 24) {
            throw new IllegalArgumentException(
                    "Age must be between 0 and 24"
            );
        }

        student.setAge(age);
        student.setAgeDetails(ageFetcher.getByAge(age));

        return student;

    }

    @Override
    public Student updateStudentEntity(Long studentId, StudentRequestVO vo) {

        Student student = studentFetcher.getById(studentId);

        if (vo.getName() != null && !vo.getName().isBlank()) {
            student.setName(vo.getName());
        }

        if (vo.getGender() != null && !vo.getGender().isBlank()) {
            student.setGender(vo.getGender());
        }

        if (vo.getDateOfBirth() != null) {

            student.setDateOfBirth(vo.getDateOfBirth());

            int age = Period.between(
                    vo.getDateOfBirth(),
                    LocalDate.now()
            ).getYears();

            if (age < 0 || age > 24) {
                throw new IllegalArgumentException(
                        "Age must be between 0 and 24"
                );
            }

            student.setAge(age);
            student.setAgeDetails(ageFetcher.getByAge(age));
        }

        return studentRepo.save(student);

    }


}
