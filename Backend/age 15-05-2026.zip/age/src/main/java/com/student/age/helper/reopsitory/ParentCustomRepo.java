package com.student.age.helper.reopsitory;

import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Parent;
import com.student.age.model.frontend.ParentProfileResponseVO;
import com.student.age.model.vo.request.ParentSearchRequestVO;
import com.student.age.model.vo.response.ParentResponseVO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ParentCustomRepo {
    List<Parent> searchParents(String name, String email, AccountStatus status,
                               String sortBy,String sortDir);


    Page<Parent> searchParents(
            ParentSearchRequestVO criteria,
            Pageable pageable
    );

}
