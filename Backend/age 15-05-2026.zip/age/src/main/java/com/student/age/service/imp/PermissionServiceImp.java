package com.student.age.service.imp;

import com.student.age.helper.reopsitory.RoleFeaturePermissionRepo;
import com.student.age.service.IPermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PermissionServiceImp implements IPermissionService {

    @Autowired
    private RoleFeaturePermissionRepo permissionRepo;

    @Override
    public boolean hasPermission(String role, String feature) {
        return permissionRepo.existsByRoleAndFeatureAndPermissionTrue(role,feature);
    }
}
