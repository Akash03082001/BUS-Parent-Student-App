package com.student.age.model.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Admin {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long adminId;

    @Column(nullable = false, unique = true, length = 100)
    private String adminName;

    @NotBlank(message = "Email must not be empty")
    @Email(message = "Invalid email format")
    @Column(nullable = false, unique = true)
    private String adminEmail;

    @Column(nullable = false)
    private String adminPassword;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AccountStatus adminStatus;

    @Column(nullable = false,updatable = false)
    private LocalDateTime adminCreatedDate;

    @Column(nullable = false)
    private LocalDateTime adminUpdatedDate;

    @PrePersist
    protected void onCreate(){
        LocalDateTime now = LocalDateTime.now();
        this.adminCreatedDate = now;
        this.adminUpdatedDate = now;
    }

    @PreUpdate
    protected  void onUpdate(){
        this.adminUpdatedDate = LocalDateTime.now();
    }

    //to make the parent dirty (telling the jpa,there is a change in entity so that @PreUpdate works)
    public void touch() {
        // no business meaning — just marks entity dirty
        this.adminUpdatedDate = LocalDateTime.now();
    }

}
