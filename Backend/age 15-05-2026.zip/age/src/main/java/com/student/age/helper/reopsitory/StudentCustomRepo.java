package com.student.age.helper.reopsitory;

import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Student;
import com.student.age.model.vo.request.StudentSearchCriteriaRequestVO;
import com.student.age.model.vo.response.StudentSearchCriteriaResponseVO;
import com.student.age.model.vo.response.StudentWithParentResponse;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface StudentCustomRepo {

    List<StudentSearchCriteriaResponseVO> searchStudents(StudentSearchCriteriaRequestVO criteria);
    Page<StudentWithParentResponse> findStudentsByCriteria(Integer age, String gender, AccountStatus parentStatus, Pageable pageable);

    //Admin usage
    Page<StudentSearchCriteriaResponseVO> searchStudents(StudentSearchCriteriaRequestVO criteria,Pageable pageable);

    //Parent usage
    Page<Student> findByParentIdWithAgeGroup(Long parentId,String searchText ,Pageable pageable);


}
