package com.student.age.config;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;
import jakarta.servlet.http.HttpServletRequest;
import javax.crypto.SecretKey;
import java.util.Date;

@Component
public class JwtUtil {

    private static final String SECRET =
            "my-super-secure-jwt-secret-key-which-is-32-chars-long";

    private final SecretKey secretKey = Keys.hmacShaKeyFor(SECRET.getBytes());

    public String generateToken(Long parentId, String email,String role) {
        return Jwts.builder()
                .setSubject(email)
                .claim("parentId", parentId)
                .claim("role",role)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 86400000)) // 1 day
                .signWith(secretKey,SignatureAlgorithm.HS256)
                .compact();
    }

    //Common method
    public Claims extractAllClaims(String token){
        return Jwts.parserBuilder()
                .setSigningKey(secretKey)
                .build()
                .parseClaimsJws(token)
                .getBody();
    }


    // ✅ Extract parentId from Authorization header
    public Long extractParentId(HttpServletRequest request) {

        String authHeader = request.getHeader("Authorization");

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new RuntimeException("Authorization header missing or invalid");
        }

        String token = authHeader.substring(7); // remove "Bearer "

        return extractAllClaims(token).get("parentId", Long.class);
    }



    // ✅ Used by JwtFilter
    public Long extractParentIdFromToken(String token) {
        return extractAllClaims(token).get("parentId", Long.class);
    }

    // used to extract role
    public String extractRole(String token){
        return extractAllClaims(token).get("role",String.class);
    }


}
