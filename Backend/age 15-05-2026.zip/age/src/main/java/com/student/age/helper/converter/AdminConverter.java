package com.student.age.helper.converter;

import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Admin;
import com.student.age.model.vo.request.AdminRequestVO;
import com.student.age.model.vo.response.AdminResponseVO;
import org.springframework.stereotype.Component;

@Component
public class AdminConverter {
    public Admin toEntity(AdminRequestVO vo){
        Admin admin = new Admin();
        admin.setAdminName(vo.getAdminName());
        admin.setAdminEmail(vo.getAdminEmail());
        admin.setAdminPassword(vo.getAdminPassword());
        admin.setAdminStatus(AccountStatus.valueOf(vo.getAdminStatus()));

        return admin;
    }
    public AdminResponseVO toResponse(Admin entity){
        if(entity == null)
            return null;
        AdminResponseVO vo = new AdminResponseVO();
        vo.setAdminEmail(entity.getAdminEmail());
        vo.setAdminName(entity.getAdminName());
        vo.setAdminStatus(entity.getAdminStatus().name());
        vo.setAdminCreatedDate(entity.getAdminCreatedDate());
        vo.setAdminUpdatedDate(entity.getAdminUpdatedDate());

        return vo;
    }
}
