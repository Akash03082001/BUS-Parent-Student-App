package com.student.age.controller.frontEnd;

import com.student.age.config.CryptoUtil;
import com.student.age.config.JwtUtil;
import com.student.age.config.SearchHashUtil;
import com.student.age.helper.fetcher.ParentFetcher;
import com.student.age.helper.reopsitory.ParentRepo;
import com.student.age.model.frontend.ParentProfileRequestVO;
import com.student.age.model.frontend.ParentProfileResponseVO;
import com.student.age.model.entity.Parent;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/parent/profile")
@RequiredArgsConstructor
@CrossOrigin(
        origins = "http://localhost:4200",
        allowedHeaders = "*",
        methods = { RequestMethod.GET, RequestMethod.PUT, RequestMethod.OPTIONS }
)
public class ProfileController {

    private final ParentRepo parentRepo;
    private final JwtUtil jwtUtil;
    private final ParentFetcher parentFetcher;
    private final CryptoUtil cryptoUtil;
    private final SearchHashUtil searchHashUtil;

    @GetMapping
    public ParentProfileResponseVO getProfile(HttpServletRequest request){
        Long parentId = jwtUtil.extractParentId(request);

        Parent parent = parentFetcher.getById(parentId);

        return new ParentProfileResponseVO(
                parent.getId(),
                cryptoUtil.decrypt(parent.getNameEnc()),
                parent.getEmail(),
                parent.getStatus()
        );
    }

    @PutMapping
    public ParentProfileResponseVO updateProfile(
            @RequestBody ParentProfileRequestVO updateRequest,
            HttpServletRequest request){
        //getting from the frontend
        Long parentId = jwtUtil.extractParentId(request);
        //checking with the backend
        Parent parent = parentFetcher.getById(parentId);
        //updating

        parent.setNameEnc(
                cryptoUtil.encrypt(updateRequest.getName())
        );
        parent.setNameHash(
                searchHashUtil.hash(updateRequest.getName().trim().toLowerCase())
        );

        parent.setEmail(updateRequest.getEmail());

        Parent updated = parentRepo.save(parent);

        return new ParentProfileResponseVO(
                updated.getId(),
                cryptoUtil.decrypt(updated.getNameEnc()),
                updated.getEmail(),
                updated.getStatus()
        );


    }

}
