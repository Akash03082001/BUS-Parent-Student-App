package com.student.age.model.vo.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GetAdminRequestVO {

    private Long adminId;
    private String adminEmail;
    private String adminName;

}
