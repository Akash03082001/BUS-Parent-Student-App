package com.student.age.controller;

import com.student.age.model.vo.request.AdminRequestVO;
import com.student.age.model.vo.request.GetAdminRequestVO;
import com.student.age.model.vo.response.AdminResponseVO;
import com.student.age.service.IAdminService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private IAdminService adminService;

    @PostMapping("/saveOrUpdate")
    public ResponseEntity<AdminResponseVO> saveOrUpdateAdmin(
            @RequestParam(required = false) Long id,
            @RequestBody @Valid AdminRequestVO vo){

        AdminResponseVO response = adminService.saveOrUpdateAdmin(id,vo);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/delete")
    public ResponseEntity<AdminResponseVO> deleteAdmin(@RequestParam Long id){

        AdminResponseVO response = adminService.deleteAdmin(id);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/get")
    public ResponseEntity<AdminResponseVO> getAdmin(
            @RequestBody GetAdminRequestVO request){

        AdminResponseVO response = adminService.getAdmin(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/getAll")
    public ResponseEntity<List<AdminResponseVO>> getAllAdmin(){
        List<AdminResponseVO> response = adminService.getAllAdmin();
        return ResponseEntity.ok(response);
    }
}
