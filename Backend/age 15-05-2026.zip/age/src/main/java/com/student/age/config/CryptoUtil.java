package com.student.age.config;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import org.springframework.stereotype.Component;

//this class is used for storing encrypted values and read them later.

@Component
public class CryptoUtil {

    private static final String SECRET = "12345678901234567890123456789012";
    private final SecretKey key;

    public CryptoUtil() {
        this.key = new SecretKeySpec(SECRET.getBytes(StandardCharsets.UTF_8),"AES");
    }

    public String encrypt(String plainText){
        try{
           Cipher cipher = Cipher.getInstance("AES");
           cipher.init(Cipher.ENCRYPT_MODE,key);
           byte[] encrypted = cipher.doFinal(plainText.getBytes());
           return Base64.getEncoder().encodeToString(encrypted);
        }catch (Exception e){
            throw new RuntimeException("Encryption Failed");
        }
    }

    public String decrypt(String cipherText){
        try{
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE,key);
            byte[] decoded = Base64.getDecoder().decode(cipherText);
            return new String(cipher.doFinal(decoded));
        } catch (Exception e) {
            throw new RuntimeException("Decryption Failed");
        }
    }
}
