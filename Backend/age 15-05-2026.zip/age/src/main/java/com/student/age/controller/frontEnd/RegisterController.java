package com.student.age.controller.frontEnd;

import com.student.age.config.CryptoUtil;
import com.student.age.config.SearchHashUtil;
import com.student.age.helper.reopsitory.ParentRepo;
import com.student.age.model.frontend.RegisterRequestVO;
import com.student.age.model.frontend.RegisterResponseVO;
import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Parent;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor  //automatically wired the class with constructor-wired
public class RegisterController {

    private final ParentRepo parentRepo;
    private final PasswordEncoder passwordEncoder;
    private final SearchHashUtil searchHashUtil;
    private final CryptoUtil cryptoUtil;

    @PostMapping("/register")
    public RegisterResponseVO register(@RequestBody RegisterRequestVO request){
        //Check email uniqueness
        if(parentRepo.findByEmail(request.getEmail()).isPresent()){
            throw  new RuntimeException("Email already registered");
        }
        //Create new Parent
        Parent parent = new Parent();

        // ✅ NAME → Encrypt + Hash
        parent.setNameEnc(
                cryptoUtil.encrypt(request.getName())
        );
        parent.setNameHash(
                searchHashUtil.hash(request.getName().trim().toLowerCase())
        );

        parent.setEmail(request.getEmail());

        //VERY IMPORTANT: encrypt password
        parent.setPassword(passwordEncoder.encode(request.getPassword()));

        //Set default status
        parent.setStatus(AccountStatus.ACTIVE);

        parent.setSearchName(request.getName().trim().toLowerCase());

        //Save to DB
        Parent savedParent = parentRepo.save(parent);

        //Return response (NO password)

        return new RegisterResponseVO(
                savedParent.getId(),
                cryptoUtil.decrypt(savedParent.getNameEnc()),
                savedParent.getEmail(),
                savedParent.getStatus()
        );

    }

}
