package com.student.age.model.vo.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AdminResponseVO {

    private String adminName;
    private String adminEmail;
    private String adminStatus;
    private LocalDateTime adminCreatedDate;
    private LocalDateTime adminUpdatedDate;

}
