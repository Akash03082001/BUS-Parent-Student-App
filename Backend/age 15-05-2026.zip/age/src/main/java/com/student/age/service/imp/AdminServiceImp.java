package com.student.age.service.imp;

import com.student.age.config.JwtUtil;
import com.student.age.helper.converter.AdminConverter;
import com.student.age.helper.fetcher.AdminFetcher;
import com.student.age.helper.reopsitory.AdminRepo;
import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Admin;
import com.student.age.model.frontend.LoginRequestVO;
import com.student.age.model.frontend.LoginResponseVO;
import com.student.age.model.vo.request.AdminRequestVO;
import com.student.age.model.vo.request.GetAdminRequestVO;
import com.student.age.model.vo.response.AdminResponseVO;
import com.student.age.service.IAdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminServiceImp implements IAdminService {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AdminConverter adminConverter;

    @Autowired
    private AdminFetcher adminFetcher;

    @Autowired
    private AdminRepo adminRepo;

    @Autowired
    private JwtUtil jwtUtil;


    @Override
    public AdminResponseVO saveOrUpdateAdmin(Long id, AdminRequestVO vo) {
        try{
            Admin admin;
            //update
            if(id!=null){
                admin = adminFetcher.getAdminById(id);

                if (vo.getAdminName() != null && !vo.getAdminName().isBlank()) {
                    admin.setAdminName(vo.getAdminName());
                }

                if (vo.getAdminEmail() != null && !vo.getAdminEmail().isBlank()) {
                    admin.setAdminEmail(vo.getAdminEmail());
                }

                if (vo.getAdminStatus() != null && !vo.getAdminStatus().isBlank()) {
                    admin.setAdminStatus(AccountStatus.valueOf(vo.getAdminStatus()));
                }

                if(vo.getAdminPassword()!=null && !vo.getAdminPassword().isBlank())
                    admin.setAdminPassword(passwordEncoder.encode(vo.getAdminPassword()));

                admin.touch();  // ✅ triggers @PreUpdate

            }else{
                //create
                admin = new Admin();
                admin.setAdminName(vo.getAdminName());
                admin.setAdminEmail(vo.getAdminEmail());
                admin.setAdminStatus(AccountStatus.valueOf(vo.getAdminStatus()));

                // to ensure password is present for admin(optional)
                if(vo.getAdminPassword() == null || vo.getAdminPassword().isBlank())
                    throw new RuntimeException("Password is required for creating admin");
                admin.setAdminPassword(passwordEncoder.encode(vo.getAdminPassword()));

            }
             admin = adminRepo.save(admin);
             return adminConverter.toResponse(admin);

        }catch (IllegalArgumentException e){
            throw new RuntimeException("Invalid admin status value", e);
        }
        catch (RuntimeException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Error while saving/updating Admin", e);
        }
    }

    @Override
    public AdminResponseVO deleteAdmin(Long id) {
        try{
            Admin admin = adminFetcher.getAdminById(id);

            // ✅ Convert to response BEFORE delete
            AdminResponseVO response = adminConverter.toResponse(admin);
            adminRepo.delete(admin);

            return response;
        }catch(RuntimeException e){
            throw e;
        }catch (Exception e){
            throw new RuntimeException("Error while deleting:"+e);
        }
    }

    @Override
    public AdminResponseVO getAdmin(GetAdminRequestVO request) {
        try{
            Admin admin;
            Long id = request.getAdminId();
            String name = request.getAdminName();
            String email = request.getAdminEmail();

            if ((id == null) &&
                    (email == null || email.isBlank()) &&
                    (name == null || name.isBlank())) {
                throw new RuntimeException("Provide at-least one filter");
            }

            if(id!=null)
                admin = adminFetcher.getAdminById(id);
            else if(email != null && !email.isBlank())
                admin = adminFetcher.getAdminByEmail(email);
            else
                admin = adminFetcher.getAdminByName(name);

            return adminConverter.toResponse(admin);

        }catch (RuntimeException e){
            throw e;
        }
        catch (Exception e) {
            throw new RuntimeException("Error while fetching Admin", e);
        }

    }

    @Override
    public List<AdminResponseVO> getAllAdmin() {
        return adminRepo.findAll()
                .stream().map(adminConverter::toResponse)
                .toList();
    }

    @Override
    public LoginResponseVO adminLogin(LoginRequestVO request) {
        Admin admin = adminFetcher.getAdminByEmail(request.getEmail());

        if(!passwordEncoder.matches(request.getPassword(), admin.getAdminPassword()))
            throw new RuntimeException("Invalid Credentials");

        String role = "ADMIN";

        String token = jwtUtil.generateToken(
                admin.getAdminId(),
                admin.getAdminEmail(),
                role
        );
        return new LoginResponseVO(
                admin.getAdminId(),
                admin.getAdminName(),
                admin.getAdminEmail(),
                admin.getAdminStatus(),
                token
        );
    }


}
