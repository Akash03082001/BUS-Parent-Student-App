package com.student.age.service;

import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Parent;
import com.student.age.model.frontend.ParentProfileRequestVO;
import com.student.age.model.frontend.ParentProfileResponseVO;
import com.student.age.model.vo.request.*;
import com.student.age.model.vo.response.ParentResponseVO;
import com.student.age.model.vo.response.StudentResponseVO;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface IParentService {

    ParentResponseVO add(ParentRequestVO vo);
    ParentResponseVO update(Long id, @Valid ParentUpdateRequestVO vo);
    void deleteById(Long id);
    ParentResponseVO getById(Long id);
    void changePassword(Long id, ChangePasswordRequestVO vo);
    List<ParentResponseVO> getAll();
    StudentResponseVO addChildToParent(Long parentId, StudentRequestVO vo);
    StudentResponseVO updateChildFromParent(Long parentId,Long childId,StudentRequestVO vo);

    void deleteChildFromParent(String role,Long parentId, Long childId);

    List<ParentResponseVO> searchParents(String name, String email, AccountStatus status,
                                         String sortBy, String sortDir);

    Page<ParentResponseVO> findByGender(String gender, int page, int size, String sortBy, String direction);
    ParentResponseVO findByEmail(String email);


    Page<ParentProfileResponseVO> getAllParents(Pageable pageable);
    Page<ParentProfileResponseVO> searchParents(ParentSearchRequestVO criteria, Pageable pageable);



    //front end
    StudentResponseVO getChildByIdForParent(Long parentId, Long childId);
    byte[] generateStudentReport(String role,Long parentId, Long childId);



}
