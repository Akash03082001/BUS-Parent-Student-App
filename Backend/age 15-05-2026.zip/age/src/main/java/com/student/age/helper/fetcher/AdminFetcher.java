package com.student.age.helper.fetcher;

import com.student.age.helper.reopsitory.AdminRepo;
import com.student.age.model.entity.Admin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AdminFetcher {

    @Autowired
    private AdminRepo adminRepo;

    public Admin getAdminById(Long id){
        return adminRepo.findById(id)
                .orElseThrow(()->new RuntimeException("Admin Id not found: "+id));
    }

    public Admin getAdminByName(String name){
        return adminRepo.findByAdminName(name)
                .orElseThrow(()->new RuntimeException("Admin name not found: "+name));
    }

    public Admin getAdminByEmail(String email){
        return adminRepo.findByAdminEmail(email)
                .orElseThrow(()->new RuntimeException("Admin email not found: "+email));
    }

}
