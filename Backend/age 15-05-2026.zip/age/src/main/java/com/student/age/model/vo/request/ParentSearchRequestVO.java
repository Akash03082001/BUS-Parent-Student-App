package com.student.age.model.vo.request;

import com.student.age.model.entity.AccountStatus;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ParentSearchRequestVO {

    private String name;
    private String email;
    private AccountStatus status;

}
