package com.student.age.service.imp;

import com.student.age.helper.reopsitory.ParentRepo;
import com.student.age.helper.reopsitory.StudentRepo;
import com.student.age.service.AdminDashboard;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class AdminDashboardImp implements AdminDashboard {

    @Autowired
    private ParentRepo parentRepo;

    @Autowired
    private StudentRepo childRepo;

    @Override
    public Long totalParents() {
        return parentRepo.count();
    }

    @Override
    public Long totalStudents() {
        return childRepo.count();
    }

    @Override
    public Map<String, Long> childGenderCount() {
        long male = childRepo.countByGenderIgnoreCase("male");
        long female = childRepo.countByGenderIgnoreCase("female");

        Map<String,Long> result = new HashMap<>();
        result.put("male",male);
        result.put("female",female);
        return result;
    }

    @Override
    public Long parentsWithChildren() {
        return parentRepo.countParentWithStudents();
    }
}
