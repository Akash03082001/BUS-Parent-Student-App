//package com.student.age.service.migration;
//
//import com.student.age.config.CryptoUtil;
//import com.student.age.config.SearchHashUtil;
//import com.student.age.helper.reopsitory.ParentRepo;
//import com.student.age.model.entity.Parent;
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.stereotype.Component;
//
//import java.util.List;
//
//@Component
//public class ParentDataMigrationRunner implements CommandLineRunner {
//
//    private final ParentRepo parentRepo;
//    private final CryptoUtil cryptoUtil;
//    private final SearchHashUtil searchHashUtil;
//
//    public ParentDataMigrationRunner(ParentRepo parentRepo,
//                                     CryptoUtil cryptoUtil, SearchHashUtil searchHashUtil, ParentRepo parentRepo1, CryptoUtil cryptoUtil1, SearchHashUtil searchHashUtil1){
//
//        this.parentRepo = parentRepo1;
//        this.cryptoUtil = cryptoUtil1;
//        this.searchHashUtil = searchHashUtil1;
//    }
//
//    @Override
//    public void run(String... args) throws Exception {
//        List<Parent> parents = parentRepo.findAll();
//        for(Parent parent : parents){
//            //  Migrate only if not already encrypted
//            if(parent.getNameEnc()==null && parent.getName()!=null){
//                parent.setNameEnc(cryptoUtil.encrypt(parent.getName()));
//                parent.setNameHash(searchHashUtil.hash(parent.getName()));
//            }
//        }
//        parentRepo.saveAll(parents);
//        System.out.println("Parent name migration completed");
//    }
//}
