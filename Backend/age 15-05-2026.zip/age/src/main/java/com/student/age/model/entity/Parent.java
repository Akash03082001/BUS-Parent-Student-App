package com.student.age.model.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "parent_details")
public class Parent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

//    @NotBlank
//    private String name;

    // ✅ Encrypted name (for display)
    @Column(name = "name_enc")
    private String nameEnc;

    // ✅ Deterministic hash (for searching)
    @Column(name = "name_hash")
    private String nameHash;

    @Column(name = "search_name", nullable = false)
    private String searchName;


    @NotBlank(message = "Email must not be empty")
    @Email(message = "Invalid email format")
    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;   // HASHED

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AccountStatus status;

    @OneToMany(mappedBy = "parent", cascade = CascadeType.ALL,orphanRemoval = true)
    private List<Student> students;

    @Column(nullable = false,updatable = false)
    private LocalDateTime createdDate;

    @Column(nullable = false)
    private LocalDateTime updatedDate;

    @PrePersist
    protected void onCreate(){
        LocalDateTime now = LocalDateTime.now();
        this.createdDate = now;
        this.updatedDate = now;
    }

    @PreUpdate
    protected  void onUpdate(){
        this.updatedDate = LocalDateTime.now();
    }

    //to make the parent dirty (telling the jpa,there is a change in entity so that @PreUpdate works)
    public void touch() {
        // no business meaning — just marks entity dirty
        this.updatedDate = LocalDateTime.now();
    }


}
