//package com.student.age.config;
//
//import com.student.age.helper.reopsitory.ParentRepo;
//import lombok.RequiredArgsConstructor;
//import org.springframework.boot.context.event.ApplicationReadyEvent;
//import org.springframework.context.event.EventListener;
//import org.springframework.stereotype.Component;
//
//@Component
//@RequiredArgsConstructor
//public class FixEmptyNames {
//
//    private final ParentRepo parentRepo;
//    private final CryptoUtil cryptoUtil;
//    private final SearchHashUtil searchHashUtil;
//
//    @EventListener(ApplicationReadyEvent.class)
//    public void fix() {
//        parentRepo.findAll().forEach(parent -> {
//            String name = cryptoUtil.decrypt(parent.getNameEnc());
//            if (name.isEmpty()) {
//                String fallback = parent.getEmail().split("@")[0];
//                parent.setNameEnc(cryptoUtil.encrypt(fallback));
//                parent.setNameHash(searchHashUtil.hash(fallback.toLowerCase()));
//                parentRepo.save(parent);
//            }
//        });
//    }
//}
//
