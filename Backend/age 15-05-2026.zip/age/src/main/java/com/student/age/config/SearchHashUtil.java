package com.student.age.config;

import org.springframework.stereotype.Component;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;

//this classed used for searching

@Component
public class SearchHashUtil {
    public String hash(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashed = digest.digest(input.trim().toLowerCase()
                    .getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hashed);
        } catch (Exception e) {
            throw new RuntimeException("Search hash failed", e);
        }
    }
}

//this is for salted ,used only for searching email and id

//private static final String SECRET = "hmac-search-secret";
//
//public String hash(String input){
//    try{
//        Mac mac = Mac.getInstance("HmacSHA256");
//        SecretKeySpec keySpec = new SecretKeySpec(SECRET.getBytes(),"HmacSHA256");
//        mac.init(keySpec);
//        byte [] result = mac.doFinal(input.toLowerCase().trim().getBytes());
//        return Base64.getEncoder().encodeToString(result);
//    }catch (Exception e){
//        throw new RuntimeException("Hashing Failed");
//    }
//}