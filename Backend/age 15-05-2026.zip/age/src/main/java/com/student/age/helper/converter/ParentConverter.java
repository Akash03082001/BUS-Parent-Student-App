package com.student.age.helper.converter;

import com.student.age.config.CryptoUtil;
import com.student.age.model.entity.Parent;
import com.student.age.model.frontend.ParentProfileResponseVO;
import com.student.age.model.vo.request.ParentRequestVO;
import com.student.age.model.vo.response.ParentResponseVO;
import com.student.age.model.vo.response.StudentResponseVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class ParentConverter {

    @Autowired
    private StudentConverter studentConverter;

    @Autowired
    private CryptoUtil cryptoUtil;


    public Parent toEntity(ParentRequestVO vo){
        Parent parent=new Parent();
        parent.setEmail(vo.getEmail());
        parent.setPassword(vo.getPassword());

        return parent;
    }

    public ParentResponseVO toResponse(Parent entity){
        if (entity == null) return null;

        ParentResponseVO vo=new ParentResponseVO();
        vo.setId(entity.getId());

        vo.setName(cryptoUtil.decrypt(entity.getNameEnc()));
        vo.setEmail(entity.getEmail());
        vo.setStatus(entity.getStatus());

       // Map students (if exist)
        if (entity.getStudents() != null && !entity.getStudents().isEmpty()) {

            List<StudentResponseVO> students =
                    entity.getStudents()
                            .stream()
                            .map(studentConverter::toResponse)
                            .collect(Collectors.toList());

            vo.setChildren(students);
        }

        return vo;
    }



    public ParentProfileResponseVO toProfileResponse(Parent entity) {
        if (entity == null) return null;

        ParentProfileResponseVO vo = new ParentProfileResponseVO();

        vo.setId(entity.getId());
        vo.setName(cryptoUtil.decrypt(entity.getNameEnc())); // ✅ decrypt
        vo.setEmail(entity.getEmail());
        vo.setStatus(entity.getStatus());

        return vo;
    }



}
