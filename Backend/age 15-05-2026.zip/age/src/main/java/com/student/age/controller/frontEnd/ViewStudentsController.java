package com.student.age.controller.frontEnd;

import com.student.age.config.JwtUtil;
import com.student.age.helper.reopsitory.StudentRepo;
import com.student.age.model.frontend.ViewStudentResponse;
import com.student.age.model.vo.request.StudentSearchCriteriaRequestVO;
import com.student.age.service.IStudentService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/parent/students")
@RequiredArgsConstructor
@CrossOrigin(
        origins = "http://localhost:4200",
        allowedHeaders = "*",
        methods = { RequestMethod.GET, RequestMethod.OPTIONS }
)
public class ViewStudentsController {

    private final JwtUtil jwtUtil;
    private final IStudentService studentService;

    @GetMapping
    public Page<ViewStudentResponse> getStudents(HttpServletRequest request,
                                                 @RequestParam(required = false) String q,
                                                 Pageable pageable
    ){
        Long parentId = jwtUtil.extractParentId(request);

        return studentService.getStudentsForParent(parentId,q,pageable);
    }




}
