//package com.student.age.service.migration;
//
//import com.student.age.config.CryptoUtil;
//import com.student.age.config.SearchHashUtil;
//import com.student.age.helper.reopsitory.ParentRepo;
//import lombok.RequiredArgsConstructor;
//import org.springframework.boot.context.event.ApplicationReadyEvent;
//import org.springframework.context.event.EventListener;
//import org.springframework.stereotype.Component;
//
//@Component
//@RequiredArgsConstructor
//public class RehashExistingNames {
//
//    private final ParentRepo parentRepo;
//    private final SearchHashUtil searchHashUtil;
//    private final CryptoUtil cryptoUtil;
//
//    @EventListener(ApplicationReadyEvent.class)
//    public void migrate() {
//        parentRepo.findAll().forEach(parent -> {
//
//            String name = cryptoUtil.decrypt(parent.getNameEnc());
//            String normalized = name.trim().toLowerCase();
//
//            parent.setNameHash(searchHashUtil.hash(normalized));
//            parent.setSearchName(normalized);
//
//            parentRepo.save(parent);
//        });
//
//        System.out.println("✅ Name normalization + rehash complete");
//    }
//}
