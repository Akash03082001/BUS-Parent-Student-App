package com.student.age.controller.frontEnd;

import com.student.age.model.vo.request.AdminRequestVO;
import com.student.age.model.vo.request.StudentSearchCriteriaRequestVO;
import com.student.age.model.vo.response.AdminResponseVO;
import com.student.age.model.vo.response.StudentSearchCriteriaResponseVO;
import com.student.age.service.AdminDashboard;
import com.student.age.service.IAdminService;
import com.student.age.service.imp.StudentServiceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class AdminDashboardController {

    @Autowired
    private AdminDashboard adminDashboardService;

    @Autowired
    private IAdminService adminService;

    @Autowired
    private StudentServiceImp studentService;

    @GetMapping("/count/parents")
    public Long totalParents(){
        return adminDashboardService.totalParents();
    }

    @GetMapping("/count/students")
    public Long totalStudents(){
        return adminDashboardService.totalStudents();
    }

    @GetMapping("/count/students/gender")
    public Map<String ,Long> studentGenderCount(){
        return adminDashboardService.childGenderCount();
    }

    @GetMapping("/count/parent-with-children")
    public Long parentWithChildren(){
        return adminDashboardService.parentsWithChildren();
    }

    @PostMapping("/update/{id}")
    public AdminResponseVO updateAdmin(@PathVariable Long id,@RequestBody AdminRequestVO request){

        System.out.println("ID: " + id);
        System.out.println("VO: " + request);

        return adminService.saveOrUpdateAdmin(id,request);
    }

    @PostMapping("/advanceSearch")
    public Page<StudentSearchCriteriaResponseVO> advanceSearchStudents(
            @RequestBody(required = false) StudentSearchCriteriaRequestVO criteria,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id,asc") String sort
    ) {

        if (criteria == null) {
            criteria = new StudentSearchCriteriaRequestVO(); // ✅ prevent crash
        }

        Pageable pageable = PageRequest.of(page, size, Sort.by(sort));

        return studentService.advanceSearchStudents(criteria, pageable);
    }


}
