package com.student.age.service;

import java.util.Map;

public interface AdminDashboard {
    Long totalParents();
    Long totalStudents();
    Map<String,Long> childGenderCount();
    Long parentsWithChildren();
}
