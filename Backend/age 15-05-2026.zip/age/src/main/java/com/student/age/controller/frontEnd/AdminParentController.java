package com.student.age.controller.frontEnd;

import com.student.age.model.frontend.ParentProfileResponseVO;
import com.student.age.model.frontend.ViewStudentResponse;
import com.student.age.model.vo.request.ParentSearchRequestVO;
import com.student.age.model.vo.request.ParentUpdateRequestVO;
import com.student.age.model.vo.response.ParentResponseVO;
import com.student.age.service.IParentService;
import com.student.age.service.IStudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/admin/parents")
public class AdminParentController {

    @Autowired
    private IParentService parentService;

    @Autowired
    private IStudentService studentService;


    // ✅ GET ALL PARENTS (Pagination)
    @GetMapping
    public Page<ParentProfileResponseVO> getAllParents(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size
    ) {
        Pageable pageable = PageRequest.of(page, size);
        return parentService.getAllParents(pageable);
    }

    // ✅ SEARCH PARENTS
    @PostMapping("/search")
    public Page<ParentProfileResponseVO> searchParents(
            @RequestBody ParentSearchRequestVO criteria,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size
    ) {
        Pageable pageable = PageRequest.of(page, size);
        return parentService.searchParents(criteria, pageable);
    }

    // ✅ GET PARENT
    @GetMapping("/{id}")
    public ParentResponseVO getParent(@PathVariable Long id) {
        return parentService.getById(id);
    }

    // ✅ UPDATE PARENT
    @PutMapping("/{id}")
    public ParentResponseVO updateParent(
            @PathVariable Long id,
            @RequestBody ParentUpdateRequestVO vo
    ) {
        return parentService.update(id, vo);
    }

    // ✅ DELETE PARENT
    @DeleteMapping("/{id}")
    public String deleteParent(@PathVariable Long id) {
        parentService.deleteById(id);
        return "Deleted Successfully";
    }

    // ✅ GET CHILDREN OF PARENT
    @GetMapping("/{parentId}/children")
    public Page<ViewStudentResponse> getChildren(
            @PathVariable Long parentId,
            @RequestParam(required = false) String searchText,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size
    ) {
        Pageable pageable = PageRequest.of(page, size);
        return studentService.getStudentsForParent(parentId, searchText, pageable);
    }


}
