package com.student.age.service;

public interface IPermissionService {

    boolean hasPermission(String role,String feature);
}
