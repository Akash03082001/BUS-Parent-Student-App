package com.student.age.helper.fetcher;


import com.student.age.config.JwtUtil;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AuthContext {

    @Autowired
    private JwtUtil jwtUtil;

    public Long getLoggedInParentId(HttpServletRequest request) {
        return jwtUtil.extractParentId(request);
    }
}

