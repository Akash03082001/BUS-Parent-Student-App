package com.student.age.helper.reopsitory.impl;

import com.student.age.helper.reopsitory.StudentCustomRepo;
import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Age;
import com.student.age.model.entity.Parent;
import com.student.age.model.entity.Student;
import com.student.age.model.vo.request.StudentSearchCriteriaRequestVO;
import com.student.age.model.vo.response.StudentSearchCriteriaResponseVO;
import com.student.age.model.vo.response.StudentWithParentResponse;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class StudentCustomRepoImpl implements StudentCustomRepo {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Page<StudentWithParentResponse> findStudentsByCriteria(Integer age, String gender, AccountStatus parentStatus, Pageable pageable) {

        // 1️⃣ Obtain CriteriaBuilder
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();

        // 2️⃣ Create CriteriaQuery
        CriteriaQuery<StudentWithParentResponse> cq = cb.createQuery(StudentWithParentResponse.class);

        // 3️⃣ Define root entity/define which table we are querying from (FROM Student)
        Root<Student> root = cq.from(Student.class);

        // 4️⃣ Join with Age entity,here ageDetails comes from the join which we use in StudentEntity
        Join<Student, Age> ageJoin = root.join("ageDetails");
        //Join with Parent entity,here parentDetails comes from the join which we use in StudentEntity
        Join<Student, Parent> parentJoin = root.join("parent");


        // 5️⃣ Create predicates (restrictions/conditions)
        List<Predicate> predicates = new ArrayList<>();

        // age > :age
        if(age!=null)
            predicates.add(cb.greaterThanOrEqualTo(root.get("age"),age));

        // gender = :gender
        if(gender!=null && !gender.isBlank()){
            predicates.add(cb.equal(
                    cb.lower(root.get("gender")),gender.toLowerCase())
            );
        }


        if (parentStatus != null) {
            predicates.add(
                    cb.equal(parentJoin.get("status"), parentStatus)
            );
        }


        // 6️⃣ Apply WHERE clause to create queries
        //cq.where(cb.and(predicates.toArray(new Predicate[0])));

// ✅ SELECT student fields + parent name
        cq.select(cb.construct(
                StudentWithParentResponse.class,
                root.get("id"),
                root.get("name"),
                root.get("age"),
                root.get("gender"),
                parentJoin.get("name")
        )).where(cb.and(predicates.toArray(new Predicate[0])));

        /*  APPLY SORTING HERE (BEFORE createQuery) */
        if(pageable.getSort().isSorted()){
            List<Order> orders = new ArrayList<>(); //Order is a built-in class
            pageable.getSort().forEach(sortOrder->{
                if (sortOrder.getProperty().equals("name")){ //name is student name
                    orders.add(sortOrder.isAscending()
                            ?cb.asc(root.get("name"))
                            :cb.desc(root.get("name")));
                }else{
                    //default = id
                    orders.add(sortOrder.isAscending()
                            ?cb.asc(root.get("id"))
                            :cb.desc(root.get("id")));
                }
            });
            cq.orderBy(orders);
        }

        //used to store the above sql query and to perform pagination operations
        TypedQuery<StudentWithParentResponse> query =
                entityManager.createQuery(cq);

        //applying pagination
        query.setFirstResult((int) pageable.getOffset());
        query.setMaxResults(pageable.getPageSize());

        List<StudentWithParentResponse> resultList = query.getResultList();

        //implementing count query
        CriteriaQuery<Long> countQuery = cb.createQuery(Long.class);
        Root<Student> countRoot = countQuery.from(Student.class);
        Join<Student,Parent> countParentJoin = countRoot.join("parent");
        List<Predicate> countPredicates = new ArrayList<>();

        if(age!=null){
            countPredicates.add(cb.greaterThanOrEqualTo(countRoot.get("age"),age));
        }
        if(gender!=null && !gender.isBlank()){
            countPredicates.add(cb.equal(cb.lower(countRoot.get("gender")),gender.toLowerCase()));
        }
        if(parentStatus!=null){
            countPredicates.add(cb.equal(countParentJoin.get("status"),parentStatus));
        }

        //to get the count value for the page
        countQuery.select(cb.count(countRoot))
                .where(cb.and(countPredicates.toArray(new Predicate[0])));



        Long total = entityManager.createQuery(countQuery).getSingleResult();



        // 7️⃣ Execute query
        return new PageImpl<>(resultList,pageable,total);
    }
    //above code is equal to:

//SELECT
//s.id,
//s.name,
//s.age,
//s.gender,
//p.name AS parent_name
//FROM student_details s
//JOIN age_details a ON s.age_group_id = a.id
//JOIN parent_details p ON s.parent_id = p.id
//WHERE s.age >= ?
//AND LOWER(s.gender) = ?
//AND p.status = ?;



//Admin use but didnt implement yet
    @Override
    public Page<StudentSearchCriteriaResponseVO> searchStudents(StudentSearchCriteriaRequestVO criteria,Pageable pageable) { //return student instead of ResponseVO
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<StudentSearchCriteriaResponseVO> cq = cb.createQuery(StudentSearchCriteriaResponseVO.class);
        Root<Student> root = cq.from(Student.class);
        Join<Student, Parent> parentJoin = root.join("parent");
        List<Predicate> predicates = new ArrayList<>();

        //for id and id should ignore all other filters
        if (criteria.getId() != null) {
            predicates.add(cb.equal(root.get("id"), criteria.getId()));
        }

        //for age and for age based on range
        if (criteria.getAge() != null) {
            predicates.add(cb.equal(root.get("age"), criteria.getAge()));
        } else if (criteria.getMinAge() != null && criteria.getMaxAge() != null) {
            predicates.add(cb.between(root.get("age"), criteria.getMinAge(), criteria.getMaxAge()));
        } else if (criteria.getMinAge() != null) {
            predicates.add(cb.greaterThanOrEqualTo(root.get("age"), criteria.getMinAge()));
        } else if (criteria.getMaxAge() != null) {
            predicates.add(cb.lessThanOrEqualTo(root.get("age"), criteria.getMaxAge()));
        }

        //for gender
        if (criteria.getGender() != null && !criteria.getGender().isBlank()) {
            predicates.add(cb.equal(cb.lower(root.get("gender")), criteria.getGender().toLowerCase()));
        }

        //for dob and for date range filters
        if (criteria.getDateOfBirth() != null) {
            predicates.add(cb.equal(root.get("dateOfBirth"), criteria.getDateOfBirth()));
        } else if (criteria.getStartDate() != null && criteria.getEndDate() != null) {
            predicates.add(cb.between(root.get("dateOfBirth"), criteria.getStartDate(), criteria.getEndDate()));
        } else if (criteria.getStartDate() != null) {
            predicates.add(cb.greaterThanOrEqualTo(root.get("dateOfBirth"), criteria.getStartDate()));
        } else if (criteria.getEndDate() != null) {
            predicates.add(cb.lessThanOrEqualTo(root.get("dateOfBirth"), criteria.getEndDate()));
        }

        //for name Conditions using %Like% operator
        if (criteria.getName() != null && !criteria.getName().isBlank()) {
            predicates.add(cb.like(cb.lower(root.get("name")), "%" + criteria.getName().toLowerCase() + "%"));
        }

        //using join to get details from parent
        if (criteria.getParentStatus() != null) {
            predicates.add(cb.equal(parentJoin.get("status"), criteria.getParentStatus()));
        }

        if (criteria.getParentId() != null) {
            predicates.add(
                    cb.equal(parentJoin.get("id"), criteria.getParentId())
            );
        }
        if(criteria.getParentName()!=null && !criteria.getParentName().isBlank()){
            predicates.add(cb.like(cb.lower(parentJoin.get("name")), "%" + criteria.getParentName().toLowerCase() + "%"));
        }

        cq.select(cb.construct(
                StudentSearchCriteriaResponseVO.class,
                root.get("id"),
                root.get("name"),
                root.get("age"),
                root.get("gender"),
                root.get("dateOfBirth"),
                parentJoin.get("id"),
                parentJoin.get("name")
        ));


        cq.where(cb.and(predicates.toArray(new Predicate[0])));

        if(pageable.getSort().isSorted()){
            List<Order> orders = new ArrayList<>();
            pageable.getSort().forEach(sortOrder->{
                String property = sortOrder.getProperty();
                Expression<?> sortExpression = switch (property) {
                    case "name" -> root.get("name");
                    case "age" -> root.get("age");
                    case "gender" -> root.get("gender");
                    case "dateOfBirth" -> root.get("dateOfBirth");
                    case "parentName" -> parentJoin.get("name");
                    default -> root.get("id");
                };
                orders.add(sortOrder.isAscending()?cb.asc(sortExpression):cb.desc(sortExpression));
            });
            cq.orderBy(orders);
        }


        //Pagination
        TypedQuery<StudentSearchCriteriaResponseVO> query =
                entityManager.createQuery(cq);

        query.setFirstResult((int) pageable.getOffset());
        query.setMaxResults(pageable.getPageSize());

        List<StudentSearchCriteriaResponseVO> resultList =
                query.getResultList();

        //count query:

        CriteriaQuery<Long> countQuery = cb.createQuery(Long.class);
        Root<Student> countRoot = countQuery.from(Student.class);
        Join<Student, Parent> countParentJoin = countRoot.join("parent");

        countQuery.select(cb.count(countRoot));
        countQuery.where(cb.and(predicates.toArray(new Predicate[0])));

        Long totalCount =
                entityManager.createQuery(countQuery).getSingleResult();

        //page result
        return new PageImpl<>(resultList, pageable, totalCount);
    }

    //for parent use
    @Override
    public Page<Student> findByParentIdWithAgeGroup(Long parentId, String searchText, Pageable pageable) {

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();

        CriteriaQuery<Student> cq = cb.createQuery(Student.class);
        Root<Student> root = cq.from(Student.class);

        root.fetch("ageDetails", JoinType.LEFT);
        Join<Student, Parent> parentJoin = root.join("parent");

        List<Predicate> predicates = new ArrayList<>();

        // ✅ Parent isolation
        predicates.add(cb.equal(parentJoin.get("id"), parentId));

        // ✅ Search by child name
        if (searchText != null && !searchText.isBlank()) {
            predicates.add(
                    cb.like(
                            cb.lower(root.get("name")),
                            "%" + searchText.toLowerCase() + "%"
                    )
            );
        }

        cq.where(cb.and(predicates.toArray(new Predicate[0])));

        // ✅ Sorting
        if (pageable.getSort().isSorted()) {
            List<Order> orders = new ArrayList<>();
            pageable.getSort().forEach(sort -> {
                Path<?> path = switch (sort.getProperty()) {
                    case "name" -> root.get("name");
                    case "age" -> root.get("age");
                    case "dateOfBirth" -> root.get("dateOfBirth");
                    default -> root.get("id");
                };
                orders.add(sort.isAscending()
                        ? cb.asc(path)
                        : cb.desc(path));
            });
            cq.orderBy(orders);
        }

        TypedQuery<Student> query = entityManager.createQuery(cq);
        query.setFirstResult((int) pageable.getOffset());
        query.setMaxResults(pageable.getPageSize());

        List<Student> data = query.getResultList();

        // ✅ Count query
        CriteriaQuery<Long> countQuery = cb.createQuery(Long.class);
        Root<Student> countRoot = countQuery.from(Student.class);
        Join<Student, Parent> countParentJoin = countRoot.join("parent");

        countQuery.select(cb.count(countRoot))
                .where(cb.equal(countParentJoin.get("id"), parentId));

        Long total = entityManager.createQuery(countQuery).getSingleResult();

        return new PageImpl<>(data, pageable, total);

    }

    @Override
    public List<StudentSearchCriteriaResponseVO> searchStudents(StudentSearchCriteriaRequestVO criteria) {


        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<StudentSearchCriteriaResponseVO> cq =
                cb.createQuery(StudentSearchCriteriaResponseVO.class);

        Root<Student> root = cq.from(Student.class);
        Join<Student, Parent> parentJoin = root.join("parent");

        List<Predicate> predicates = new ArrayList<>();

        // ✅ SAME predicate logic as paginated version
        // (age, gender, date range, name, parentId, etc.)

        cq.select(cb.construct(
                StudentSearchCriteriaResponseVO.class,
                root.get("id"),
                root.get("name"),
                root.get("age"),
                root.get("gender"),
                root.get("dateOfBirth"),
                parentJoin.get("id"),
                parentJoin.get("name")
        ));

        cq.where(cb.and(predicates.toArray(new Predicate[0])));

        return entityManager.createQuery(cq).getResultList();

    }

//
//    @Override
//    public List<Student> findByParentIdWithAgeGroup(Long parentId) {
//
//        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
//        CriteriaQuery<Student> cq = cb.createQuery(Student.class);
//
//        // Root entity
//        Root<Student> studentRoot = cq.from(Student.class);
//
//        // JOIN FETCH ageDetails
//        studentRoot.fetch("ageDetails",JoinType.LEFT);
//
//        // JOIN parent
//        Join<Student, Parent> parentJoin = studentRoot.join("parent", JoinType.INNER);
//
//        // WHERE student.parentId = :parentId
//        Predicate parentPredicate =
//                cb.equal(parentJoin.get("id"), parentId);
//
//        cq.select(studentRoot)
//                .where(parentPredicate);
//
//
//        TypedQuery<Student> query = entityManager.createQuery(cq);
//
//        return query.getResultList();
//    }
//
//    @Override
//    public Page<Student> findByParentIdWithAgeGroup(Long parentId, Pageable pageable) {
//        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
//        CriteriaQuery<Student> cq = cb.createQuery(Student.class);
//        Root<Student> root = cq.from(Student.class);
//        root.fetch("ageDetails",JoinType.LEFT);
//        Join<Student,Parent> parentJoin = root.join("parent");
//        Predicate parentPredicate = cb.equal(parentJoin.get("id"),parentId);
//        cq.select(root).where(parentPredicate);
//
//        //Pagination methods are available in typedQuery not Criteria Query
//        TypedQuery<Student> query = entityManager.createQuery(cq);
//        query.setFirstResult((int) pageable.getOffset());
//        query.setMaxResults(pageable.getPageSize());
//
//        List<Student> students = query.getResultList();
//
//        //count query
//        CriteriaQuery<Long> countQuery = cb.createQuery(Long.class);
//        Root<Student> countRoot = countQuery.from(Student.class);
//        Join<Student,Parent> countParentJoin = countRoot.join("parent");
//
//        countQuery.select(cb.count(countRoot)).where(cb.equal(countParentJoin.get("id"),parentId));
//
//        Long total = entityManager.createQuery(countQuery).getSingleResult();
//        return new PageImpl<>(students,pageable,total);
//    }


}



