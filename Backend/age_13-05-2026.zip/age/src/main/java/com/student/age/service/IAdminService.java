package com.student.age.service;

import com.student.age.model.vo.request.AdminRequestVO;
import com.student.age.model.vo.request.GetAdminRequestVO;
import com.student.age.model.vo.response.AdminResponseVO;

import java.util.List;

public interface IAdminService {
    AdminResponseVO saveOrUpdateAdmin(Long id, AdminRequestVO vo);
    AdminResponseVO deleteAdmin(Long id);
    AdminResponseVO getAdmin(GetAdminRequestVO request);
    List<AdminResponseVO> getAllAdmin();
}
