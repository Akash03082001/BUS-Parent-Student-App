package com.student.age.helper.fetcher;

import com.student.age.exception.ResourceNotFoundException;
import com.student.age.helper.reopsitory.StudentRepo;
import com.student.age.model.entity.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StudentFetcher {

    @Autowired
    private StudentRepo studentRepo;

    public Student getById(Long id){
        return studentRepo.findById(id)
                .orElseThrow(()->new ResourceNotFoundException("Id not found: "+id));
    }
}
