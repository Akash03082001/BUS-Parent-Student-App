package com.student.age.helper.store;

import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class ReportStore {

    private final Map<String, byte[]> store = new ConcurrentHashMap<>();

    public String save(byte[] pdf) {
        String reportId = UUID.randomUUID().toString();
        store.put(reportId, pdf);
        return reportId;
    }

    public byte[] get(String reportId) {
        return store.get(reportId);
    }

    public void remove(String reportId) {
        store.remove(reportId);
    }

}
