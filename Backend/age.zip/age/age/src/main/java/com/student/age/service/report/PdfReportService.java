package com.student.age.service.report;

import com.lowagie.text.Image;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import com.student.age.model.entity.Age;
import com.student.age.model.entity.Student;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

@Service
public class PdfReportService {

    public byte[] generateStudentPdf(Student student) {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

            Document document = new Document(
                    PageSize.A4, 36, 36, 36, 36
            );
            PdfWriter.getInstance(document, baos);
            document.open();

            document.add(new Paragraph("Student Progress Report"));
            document.add(new Paragraph("Name: " + student.getName()));
            document.add(new Paragraph("Age: " + student.getAge()));
            document.add(new Paragraph("Gender: " + student.getGender()));
            document.add(new Paragraph("DOB: " + student.getDateOfBirth()));
            document.add(new Paragraph("Age Group: " + student.getAgeDetails().getLabel()));

            document.add(new Paragraph("\n"));

            Image chart = Image.getInstance(
                    createAgeChartImage(student)
            );
            document.add(chart);

            document.close();
            return baos.toByteArray();

        } catch (Exception e) {
            throw new RuntimeException("Failed to generate PDF", e);
        }

    }

    //For Chart
    private byte[] createAgeChartImage(Student student) throws IOException {

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(student.getAge(), "Age", "Child Age");

        JFreeChart chart = ChartFactory.createBarChart(
                "Age Chart",
                "Metric",
                "Value",
                dataset
        );

        chart.setBackgroundPaint(Color.WHITE);

        BufferedImage image = chart.createBufferedImage(500, 300);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(image, "png", baos);

        return baos.toByteArray();
    }


}
