package com.student.age.service;

import com.student.age.model.vo.request.AgeRequestVO;
import com.student.age.model.vo.response.AgeResponseVO;

import java.util.List;

public interface IAgeService {
    AgeResponseVO add(AgeRequestVO vo);
    AgeResponseVO update(Long id,AgeRequestVO vo);
    AgeResponseVO getById(Long id);
    void deleteById(Long id);
    List<AgeResponseVO> getAll();

}
