package com.student.age.model.frontend;

import com.student.age.model.entity.AccountStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class LoginResponseVO {

    private Long id;
    private String name;
    private String email;
    private AccountStatus status;
    private String token;


}
