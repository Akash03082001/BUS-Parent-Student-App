package com.student.age.helper.report;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.ColumnText;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfPageEventHelper;
import com.lowagie.text.pdf.PdfWriter;

public class PdfPageNumberEvent extends PdfPageEventHelper {

    private final Font footerFont =
            new Font(Font.HELVETICA, 9, Font.NORMAL);

    @Override
    public void onEndPage(PdfWriter writer, Document document) {

        PdfContentByte canvas = writer.getDirectContent();

        String pageText = "Page " + writer.getPageNumber();

        Phrase footer = new Phrase(pageText, footerFont);

        // ✅ Align center at bottom of page
        ColumnText.showTextAligned(
                canvas,
                Element.ALIGN_CENTER,
                footer,
                (document.right() + document.left()) / 2,
                document.bottom() - 10,
                0
        );
    }

}
