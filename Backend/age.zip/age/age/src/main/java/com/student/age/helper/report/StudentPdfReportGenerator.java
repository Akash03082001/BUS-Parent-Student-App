package com.student.age.helper.report;

import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import com.student.age.model.vo.response.StudentSearchCriteriaResponseVO;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StudentPdfReportGenerator {

    public static byte[] generateReport(
            List<StudentSearchCriteriaResponseVO> students) {

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        // ✅ SAFETY TIP: Standard margins prevent layout overflow
        Document document = new Document(
                PageSize.A4, 36, 36, 36, 36
        );

        try {
            PdfWriter writer = PdfWriter.getInstance(document, out);
            writer.setPageEvent(new PdfPageNumberEvent());

            document.open();

            /* ================================
               MAIN TITLE (Page 1)
               ================================ */
            Font titleFont = new Font(Font.HELVETICA, 16, Font.BOLD);
            Paragraph title = new Paragraph("Student Report", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(Chunk.NEWLINE);

            /* ================================
               PAGE 1: GENDER DISTRIBUTION
               ================================ */
            addSectionHeading(
                    document,
                    "Gender Distribution",
                    new Color(76, 175, 80) // Green
            );

            byte[] genderChart =
                    StudentGenderChartGenerator.generateGenderPieChart(students);

            Image genderImg = Image.getInstance(genderChart);
            genderImg.scaleToFit(500, 300);
            genderImg.setAlignment(Element.ALIGN_CENTER);
            document.add(genderImg);

            /* ================================
               PAGE 2: STUDENT DETAILS TABLE
               ================================ */
            document.newPage();

            addSectionHeading(
                    document,
                    "Student Details",
                    new Color(33, 150, 243) // Blue
            );

            PdfPTable table = new PdfPTable(7);
            table.setWidthPercentage(100);
            addHeader(table);

            for (StudentSearchCriteriaResponseVO s : students) {
                String gender = s.getGender();

                addGenderStyledCell(table, String.valueOf(s.getId()), gender);
                addGenderStyledCell(table, s.getName(), gender);
                addGenderStyledCell(table, String.valueOf(s.getAge()), gender);
                addGenderStyledCell(table, s.getGender(), gender);
                addGenderStyledCell(table,
                        String.valueOf(s.getDateOfBirth()), gender);
                addGenderStyledCell(table,
                        String.valueOf(s.getParentId()), gender);
                addGenderStyledCell(table, s.getParentName(), gender);
            }

            document.add(table);

            /* ================================
               PAGE 3: AGE DISTRIBUTION
               ================================ */
            document.newPage();

            addSectionHeading(
                    document,
                    "Age Distribution",
                    new Color(255, 152, 0) // Orange
            );

            byte[] ageChart =
                    StudentAgeBar.generateAgeBarChart(students);

            Image ageImg = Image.getInstance(ageChart);
            ageImg.scalePercent(75);
            ageImg.setAlignment(Element.ALIGN_CENTER);
            document.add(ageImg);
            document.add(Chunk.NEWLINE);

            addAgeDetailsBelowChart(document, students);

            document.close();

        } catch (Exception e) {
            throw new RuntimeException("Error while generating PDF", e);
        }

        return out.toByteArray();
    }

    /* ================================
       TABLE HEADER
       ================================ */
    private static void addHeader(PdfPTable table) {

        Font headerFont = new Font(
                Font.HELVETICA, 10, Font.BOLD, Color.WHITE);
        Color headerBg = new Color(63, 81, 181); // Indigo

        String[] headers = {
                "ID", "Name", "Age", "Gender",
                "DOB", "Parent ID", "Parent Name"
        };

        for (String header : headers) {
            PdfPCell cell = new PdfPCell(
                    new Phrase(header, headerFont));
            cell.setBackgroundColor(headerBg);
            cell.setPadding(6);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(cell);
        }
    }

    /* ================================
       GENDER‑BASED ROW STYLING
       ================================ */
    private static void addGenderStyledCell(
            PdfPTable table,
            String text,
            String gender) {

        Color bg = "Male".equalsIgnoreCase(gender)
                ? new Color(227, 242, 253)   // Light Blue
                : new Color(252, 228, 236);  // Light Pink

        PdfPCell cell = new PdfPCell(
                new Phrase(text,
                        new Font(Font.HELVETICA, 10))
        );
        cell.setBackgroundColor(bg);
        cell.setPadding(6);
        table.addCell(cell);
    }

    /* ================================
       AGE DETAILS (TEXT BELOW BAR CHART)
       ================================ */
    private static void addAgeDetailsBelowChart(
            Document document,
            List<StudentSearchCriteriaResponseVO> students)
            throws DocumentException {

        Map<Integer, Long> ageCount =
                students.stream()
                        .collect(Collectors.groupingBy(
                                StudentSearchCriteriaResponseVO::getAge,
                                Collectors.counting()
                        ));

        int total = students.size();

        Font headerFont = new Font(Font.HELVETICA, 12, Font.BOLD);
        Font bodyFont = new Font(Font.HELVETICA, 11);

        Paragraph header =
                new Paragraph("Age‑wise Distribution:", headerFont);
        header.setSpacingBefore(10);
        document.add(header);

        ageCount.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .forEach(e -> {
                    double percent =
                            (e.getValue() * 100.0) / total;

                    Paragraph line = new Paragraph(
                            "Age " + e.getKey()
                                    + " : "
                                    + e.getValue()
                                    + " students ("
                                    + String.format("%.1f", percent)
                                    + "%)",
                            bodyFont
                    );
                    try {
                        document.add(line);
                    } catch (DocumentException ex) {
                        throw new RuntimeException(ex);
                    }
                });
    }

    /* ================================
       COLORED SECTION HEADINGS
       ================================ */
    private static void addSectionHeading(
            Document document,
            String title,
            Color backgroundColor)
            throws DocumentException {

        PdfPCell cell = new PdfPCell(
                new Phrase(title,
                        new Font(Font.HELVETICA, 13,
                                Font.BOLD, Color.WHITE))
        );
        cell.setBackgroundColor(backgroundColor);
        cell.setPadding(8);
        cell.setBorder(Rectangle.NO_BORDER);

        PdfPTable table = new PdfPTable(1);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10);
        table.setSpacingAfter(6);
        table.addCell(cell);

        document.add(table);
    }
}