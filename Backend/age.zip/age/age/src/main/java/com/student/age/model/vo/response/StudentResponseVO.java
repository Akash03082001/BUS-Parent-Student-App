package com.student.age.model.vo.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.student.age.model.entity.AccountStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class StudentResponseVO {
    private Long id;
    private String name;
    private Integer age;
    private String gender;
//    private AccountStatus status;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate dateOfBirth;

    private String ageGroupLabel;
}
