package com.student.age.controller.frontEnd;

import com.student.age.config.JwtUtil;
import com.student.age.service.IParentService;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/parent/students")
@RequiredArgsConstructor
@CrossOrigin(
        origins = "http://localhost:4200",
        allowedHeaders = "*",
        methods = {
                RequestMethod.GET,
                RequestMethod.POST,
                RequestMethod.DELETE,
                RequestMethod.OPTIONS
        }
)
public class PdfController {
    private final JwtUtil jwtUtil;
    private final IParentService parentService;

    @GetMapping("/{childId}/report")
    public ResponseEntity<byte[]> downloadStudentReport(
            @PathVariable Long childId,
            HttpServletRequest request
    ) {
        Long parentId = jwtUtil.extractParentId(request);

        byte[] pdf = parentService.generateStudentReport(parentId, childId);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=student-report-" + childId + ".pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdf);
    }


}
