package com.student.age.controller;

import com.student.age.helper.reopsitory.AgeRepo;
import com.student.age.model.vo.request.AgeRequestVO;
import com.student.age.model.vo.response.AgeResponseVO;
import com.student.age.service.imp.AgeServiceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ages")
public class AgeController {

    @Autowired
    private AgeServiceImp ageService;

    @PostMapping
    public AgeResponseVO add(@RequestBody AgeRequestVO vo){
        return ageService.add(vo);
    }

    @PostMapping("/{id}")
    public AgeResponseVO update(@PathVariable Long id,@RequestBody AgeRequestVO vo){
        return ageService.update(id,vo);
    }

    @GetMapping("/{id}")
    public AgeResponseVO getById(@PathVariable Long id){
        return ageService.getById(id);
    }

    @DeleteMapping("/{id}")
    String deleteById(@PathVariable Long id){
        ageService.deleteById(id);
        return "Deleted Successfully";
    }

    @GetMapping
    List<AgeResponseVO> getAll(){
        return ageService.getAll();
    }
}
