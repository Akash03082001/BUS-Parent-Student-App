package com.student.age.helper.converter;

import com.student.age.model.entity.Student;
import com.student.age.model.vo.request.StudentRequestVO;
import com.student.age.model.vo.response.StudentResponseVO;
import org.springframework.stereotype.Component;

@Component
public class StudentConverter {

    public Student toEntity(StudentRequestVO vo){

        Student student=new Student();
        student.setName(vo.getName());
        student.setGender(vo.getGender());
        student.setDateOfBirth(vo.getDateOfBirth());

        return student;
    }

    public StudentResponseVO toResponse(Student entity){

        if (entity == null) return null;

        StudentResponseVO studentResponseVO=new StudentResponseVO();
        studentResponseVO.setId(entity.getId());
        studentResponseVO.setName(entity.getName());
        studentResponseVO.setAge(entity.getAge());
        studentResponseVO.setGender(entity.getGender());
        studentResponseVO.setDateOfBirth(entity.getDateOfBirth());

        if(entity.getAgeDetails()!=null)
            studentResponseVO.setAgeGroupLabel(entity.getAgeDetails().getLabel());

        return studentResponseVO;
    }


}
