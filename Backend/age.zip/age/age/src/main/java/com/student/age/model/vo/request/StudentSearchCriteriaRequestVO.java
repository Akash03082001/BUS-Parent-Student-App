package com.student.age.model.vo.request;

import com.student.age.model.entity.AccountStatus;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class StudentSearchCriteriaRequestVO {

    private Long id;
    private Integer age;
    private Integer minAge;
    private Integer maxAge;
    private String gender;
    private String name;
    private LocalDate dateOfBirth;

    // ✅ Date range filters
    private LocalDate startDate;
    private LocalDate endDate;

    // ✅ Parent-based filter
    private Long parentId;
    private String parentName;
    private AccountStatus parentStatus;



}
