package com.student.age.model.frontend;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ViewStudentResponse {

    private Long id;
    private String name;
    private String gender;
    private Integer age;
    private LocalDate dateOfBirth;
    private String ageGroupLabel;

}
