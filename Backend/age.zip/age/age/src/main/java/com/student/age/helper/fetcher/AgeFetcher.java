package com.student.age.helper.fetcher;

import com.student.age.exception.ResourceNotFoundException;
import com.student.age.helper.reopsitory.AgeRepo;
import com.student.age.model.entity.Age;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class AgeFetcher {

    @Autowired
    private AgeRepo ageRepo;


    public Age getById(Long id){
        return ageRepo.findById(id)
            .orElseThrow(()->new ResourceNotFoundException("Id not found: "+id));
        }



    public Age getByAge(Integer age) {
        if (age == null) {
            throw new IllegalArgumentException("Age must not be null");
        }
        return (Age) ageRepo
                .findByMinAgeLessThanEqualAndMaxAgeGreaterThanEqual(age, age)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "No age group found for age " + age
                        ));
    }


}
