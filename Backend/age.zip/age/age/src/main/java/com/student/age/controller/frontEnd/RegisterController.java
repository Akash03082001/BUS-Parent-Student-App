package com.student.age.controller.frontEnd;

import com.student.age.helper.reopsitory.ParentRepo;
import com.student.age.model.frontend.RegisterRequestVO;
import com.student.age.model.frontend.RegisterResponseVO;
import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Parent;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
public class RegisterController {

    private final ParentRepo parentRepo;
    private final PasswordEncoder passwordEncoder;

    @PostMapping("/register")
    public RegisterResponseVO register(@RequestBody RegisterRequestVO request){
        //Check email uniqueness
        if(parentRepo.findByEmail(request.getEmail()).isPresent()){
            throw  new RuntimeException("Email already registered");
        }
        //Create new Parent
        Parent parent = new Parent();
        parent.setName(request.getName());
        parent.setEmail(request.getEmail());

        //VERY IMPORTANT: encrypt password
        parent.setPassword(passwordEncoder.encode(request.getPassword()));

        //Set default status
        parent.setStatus(AccountStatus.ACTIVE);

        //Save to DB
        Parent savedParent = parentRepo.save(parent);

        //Return response (NO password)

        return new RegisterResponseVO(
                savedParent.getId(),
                savedParent.getName(),
                savedParent.getEmail(),
                savedParent.getStatus()
        );

    }

}
