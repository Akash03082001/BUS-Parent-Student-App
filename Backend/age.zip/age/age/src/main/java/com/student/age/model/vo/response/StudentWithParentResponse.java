package com.student.age.model.vo.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class StudentWithParentResponse {

    private Long studentId;
    private String studentName;
    private Integer age;
    private String gender;
    private String parentName;

}
