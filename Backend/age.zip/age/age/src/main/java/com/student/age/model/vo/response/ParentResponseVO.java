package com.student.age.model.vo.response;

import com.student.age.model.entity.AccountStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ParentResponseVO {

    private Long id;
    private String name;
    private String email;
    private AccountStatus status;
    private List<StudentResponseVO> children;

}
