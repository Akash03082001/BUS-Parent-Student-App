package com.student.age.helper.reopsitory;

import com.student.age.model.entity.Parent;
import com.student.age.model.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface StudentRepo extends JpaRepository<Student,Long>,StudentCustomRepo {
    List<Student> findByAgeGreaterThan(Integer age);


    @Query("SELECT s FROM Student s WHERE LOWER(s.name) LIKE LOWER(CONCAT(:prefix, '%'))")
    List<Student> findStudentsByNamePrefix(@Param("prefix") String prefix);
    
    List<Student> findByAge(Integer age);

    Optional<Student> findByIdAndParentId(Long id, Long parentId);

}
