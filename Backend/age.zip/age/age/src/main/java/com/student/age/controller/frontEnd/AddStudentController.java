package com.student.age.controller.frontEnd;
import com.student.age.config.JwtUtil;
import com.student.age.model.frontend.AddStudentRequest;
import com.student.age.model.vo.request.StudentRequestVO;
import com.student.age.model.vo.response.StudentResponseVO;
import com.student.age.service.IParentService;
import com.student.age.service.IStudentService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/parent/students")
@RequiredArgsConstructor
@CrossOrigin(
        origins = "http://localhost:4200",
        allowedHeaders = "*",
        methods = {
                RequestMethod.GET,
                RequestMethod.POST,
                RequestMethod.DELETE,
                RequestMethod.OPTIONS
        }
)
public class AddStudentController {
    private final JwtUtil jwtUtil;
    private final IParentService parentService;
    private final IStudentService studentService;

    // ✅ 1. ADD STUDENT
    @PostMapping
    public StudentResponseVO addStudent(
            @RequestBody @Valid AddStudentRequest request,
            HttpServletRequest httpRequest
    ) {
        Long parentId = jwtUtil.extractParentId(httpRequest);
        return studentService.add(parentId, mapToStudentRequestVO(request));
    }

    // ✅ 2. GET STUDENT FOR PREFILL (READ-ONLY)
    @GetMapping("/{childId}")
    public StudentResponseVO getStudentById(
            @PathVariable Long childId,
            HttpServletRequest request
    ) {
        Long parentId = jwtUtil.extractParentId(request);
        return parentService.getChildByIdForParent(parentId, childId);
    }

    // ✅ 3. UPDATE STUDENT
    @PostMapping("/{childId}")
    public StudentResponseVO updateStudent(
            @PathVariable Long childId,
            @RequestBody StudentRequestVO vo,
            HttpServletRequest request
    ) {
        Long parentId = jwtUtil.extractParentId(request);
        return parentService.updateChildFromParent(parentId, childId, vo);
    }

    // ✅ 4. DELETE STUDENT
    @DeleteMapping("/{childId}/delete")
    public void deleteStudent(
            @PathVariable Long childId,
            HttpServletRequest request
    ) {
        Long parentId = jwtUtil.extractParentId(request);
        parentService.deleteChildFromParent(parentId, childId);
    }

    private StudentRequestVO mapToStudentRequestVO(AddStudentRequest request) {
        StudentRequestVO vo = new StudentRequestVO();
        vo.setName(request.getName());
        vo.setGender(request.getGender());
        vo.setDateOfBirth(request.getDateOfBirth());
        return vo;
    }
}