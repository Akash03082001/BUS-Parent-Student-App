package com.student.age.helper.fetcher;

import com.student.age.exception.ResourceNotFoundException;
import com.student.age.helper.reopsitory.ParentRepo;
import com.student.age.model.entity.Parent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ParentFetcher {
    @Autowired
    private ParentRepo parentRepo;

    public Parent getById(Long id){
        return parentRepo.findById(id)
                .orElseThrow(()->new ResourceNotFoundException("Id not found: "+id));
    }
}
