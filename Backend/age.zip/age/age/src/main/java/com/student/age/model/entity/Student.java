package com.student.age.model.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "student_details")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Name must not be empty")
    @Size(min = 2,max = 50,message = "Name must be between 2 and 50 characters")
    @Column(nullable = false)
    private String name;

    @NotNull(message = "Age is required")
    @Min(value = 0,message = "Age must be at least zero")
    @Max(value = 24,message = "Boomer Uncle")
    @Column(nullable = false)
    private Integer age;

    @Column(nullable = false)
    private String gender;

    @Past(message = "Date of birth must be in the past")
    @Column(nullable = false)
    private LocalDate dateOfBirth;

//    @Enumerated(EnumType.STRING)
//    private AccountStatus status;


    //student entity is child here and parent entity is the parent
    @ManyToOne(optional = false)
    @JoinColumn(name = "parent_id")
    private Parent parent;

    //optional : child object should always have parent object
    @ManyToOne(optional = false)
    @JoinColumn(name = "age_group_id",nullable = false)
    private Age ageDetails;

}
