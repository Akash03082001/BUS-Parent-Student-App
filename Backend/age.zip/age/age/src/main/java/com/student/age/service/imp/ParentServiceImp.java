package com.student.age.service.imp;

import com.student.age.exception.ResourceNotFoundException;
import com.student.age.helper.converter.ParentConverter;
import com.student.age.helper.converter.StudentConverter;
import com.student.age.helper.fetcher.ParentFetcher;
import com.student.age.helper.fetcher.StudentFetcher;
import com.student.age.helper.reopsitory.ParentRepo;
import com.student.age.helper.reopsitory.StudentRepo;
import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Parent;
import com.student.age.model.entity.Student;
import com.student.age.model.vo.request.ChangePasswordRequestVO;
import com.student.age.model.vo.request.ParentRequestVO;
import com.student.age.model.vo.request.ParentUpdateRequestVO;
import com.student.age.model.vo.request.StudentRequestVO;
import com.student.age.model.vo.response.ParentResponseVO;
import com.student.age.model.vo.response.StudentResponseVO;
import com.student.age.service.IParentService;
import com.student.age.service.report.PdfReportService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ParentServiceImp implements IParentService {

    @Autowired
    private ParentRepo parentRepo;

    @Autowired
    private ParentFetcher parentFetcher;

    @Autowired
    private ParentConverter parentConverter;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private StudentServiceImp studentService;

    @Autowired
    private StudentRepo studentRepo;

    @Autowired
    private StudentConverter studentConverter;

    @Autowired
    private StudentFetcher studentFetcher;

    @Autowired
    private PdfReportService pdfReportService;


    @Override
    public ParentResponseVO add(ParentRequestVO vo) {

        // Convert request → entity
        Parent parent = parentConverter.toEntity(vo);

        // Hash password
        parent.setPassword(
                passwordEncoder.encode(vo.getPassword())
        );

        // System-controlled status
        parent.setStatus(AccountStatus.ACTIVE);

        Parent savedParent = parentRepo.save(parent);
        return parentConverter.toResponse(savedParent);

    }

    @Override
    public ParentResponseVO update(Long id, @Valid ParentUpdateRequestVO vo) {

        Parent parent=parentFetcher.getById(id);

        if(vo.getName() !=null && !vo.getName().isBlank())
            parent.setName(vo.getName());
        if(vo.getEmail()!=null && !vo.getEmail().isBlank())
            parent.setEmail(vo.getEmail());

        return parentConverter.toResponse(parentRepo.save(parent));

    }

    @Override
    public void deleteById(Long id) {
        Parent parent = parentFetcher.getById(id);
        parent.setStatus(AccountStatus.DELETED);
        parentRepo.save(parent);

    }

    @Override
    public ParentResponseVO getById(Long id) {
        return parentConverter.toResponse(
                parentFetcher.getById(id)
        );
    }

    @Override
    public void changePassword(Long id, ChangePasswordRequestVO vo) {

        Parent parent = parentFetcher.getById(id);

        if (!passwordEncoder.matches(
                vo.getOldPassword(),
                parent.getPassword())) {
            throw new IllegalArgumentException(
                    "Old password is incorrect"
            );
        }

        parent.setPassword(
                passwordEncoder.encode(vo.getNewPassword())
        );

        parentRepo.save(parent);

    }

    @Override
    public List<ParentResponseVO> getAll() {
        return parentRepo.findAll()
                .stream().map(parentConverter::toResponse)
                .toList();
    }

    @Override
    public StudentResponseVO addChildToParent(Long parentId, StudentRequestVO vo) {
        // 1️⃣ Fetch parent (ownership root)
        Parent parent = parentFetcher.getById(parentId);

        // 2️⃣ Delegate child creation to StudentService/reusing the method from child entity
        Student student=studentService.createStudentEntity(vo);

        // 3️⃣ Map child → parent (THIS IS THE KEY LINE)
        student.setParent(parent);

        // 4️⃣ Save student
        Student savedStudent = studentRepo.save(student);

        return studentConverter.toResponse(savedStudent);

    }

    @Override
    public StudentResponseVO updateChildFromParent(Long parentId, Long childId, StudentRequestVO vo) {

        // 1️⃣ Fetch parent
        Parent parent = parentFetcher.getById(parentId);

        // 2️⃣ Fetch student (ownership check)
        Student student = studentFetcher.getById(childId);

        if (!student.getParent().getId().equals(parent.getId())) {
            throw new IllegalStateException(
                    "Student does not belong to this parent"
            );
        }

        // 3️⃣ Delegate update to StudentService
        Student updatedStudent =
                studentService.updateStudentEntity(childId, vo);

        return studentConverter.toResponse(updatedStudent);

    }

    @Override
    public StudentResponseVO getChildByIdForParent(Long parentId, Long childId) {
        Student student = studentRepo.findByIdAndParentId(childId,parentId)
                .orElseThrow(()-> new IllegalArgumentException
                        ("Student not found or does not belong to parent"));
        return studentConverter.toResponse(student);
    }

    //frontend pdf generator
    @Override
    public byte[] generateStudentReport(Long parentId, Long childId) {

        Student student = studentRepo.findByIdAndParentId(childId, parentId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Student not found or access denied"));

        return pdfReportService.generateStudentPdf(student);
    }



    @Override
    public void deleteChildFromParent(Long parentId, Long childId) {

// 1️⃣ Fetch parent
        Parent parent = parentFetcher.getById(parentId);

        // 2️⃣ Fetch child
        Student student = studentFetcher.getById(childId);

        // 3️⃣ Ownership validation (CRITICAL)
        if (!student.getParent().getId().equals(parent.getId())) {
            throw new IllegalStateException(
                    "Student does not belong to this parent"
            );
        }

        // 4️⃣ Delegate delete to StudentService
        studentService.deleteById(childId);

    }

    @Override
    public List<ParentResponseVO> searchParents(String name, String email, AccountStatus status) {
        return parentRepo.searchParents(name, email, status)
                .stream()
                .map(parentConverter::toResponse)
                .toList();
    }

    @Override
    public Page<ParentResponseVO> findByGender(String gender,int page,int size,String sortBy,String direction) {

        //Single sorting
//        Pageable pageable = PageRequest.of(
//                page,
//                size,
//                Sort.by("email").descending()
//        );
        Sort sort =
                "desc".equalsIgnoreCase(direction)
                        ? Sort.by(sortBy).descending()
                        : Sort.by(sortBy).ascending();

        Pageable pageable = PageRequest.of(page-1,size,sort);
        Page<Parent> parentPage =
                parentRepo.findDistinctByStudentsGenderIgnoreCase(gender,pageable);

        return parentPage.map(parent -> {

            // ✅ Filter only matching students
            parent.setStudents(
                    parent.getStudents().stream()
                            .filter(s ->
                                    s.getGender() != null &&
                                            s.getGender().equalsIgnoreCase(gender))
                            .toList()
            );

            return parentConverter.toResponse(parent);
        });


    }

    @Override
    public ParentResponseVO findByEmail(String email) {
        Parent parent = parentRepo.findByEmail(email)
                .orElseThrow(()-> new ResourceNotFoundException("Invalid Email"));
        return parentConverter.toResponse(parent);
    }


}
