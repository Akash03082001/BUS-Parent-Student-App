package com.student.age.service.imp;

import com.student.age.exception.ResourceNotFoundException;
import com.student.age.helper.converter.AgeConverter;
import com.student.age.helper.fetcher.AgeFetcher;
import com.student.age.helper.reopsitory.AgeRepo;
import com.student.age.model.entity.Age;
import com.student.age.model.vo.request.AgeRequestVO;
import com.student.age.model.vo.response.AgeResponseVO;
import com.student.age.service.IAgeService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class AgeServiceImp implements IAgeService {

    @Autowired
    private AgeFetcher ageFetcher;

    @Autowired
    private AgeRepo ageRepo;

    @Override
    @Transactional
    public AgeResponseVO add(AgeRequestVO vo) {

        // 1️⃣ Validate min-max range
        if (vo.getMinAge() > vo.getMaxAge()) {
            throw new IllegalArgumentException(
                    "Minimum age cannot be greater than maximum age"
            );
        }

        // 2️⃣ Validate label uniqueness
        if (ageRepo.existsByLabelIgnoreCase(vo.getLabel())) {
            throw new IllegalStateException(
                    "Age label already exists"
            );
        }

        // 3️⃣ Validate overlapping age ranges
        boolean isOverlapping = ageRepo
                .existsByMinAgeLessThanEqualAndMaxAgeGreaterThanEqual(
                        vo.getMaxAge(), vo.getMinAge()
                );

        if (isOverlapping) {
            throw new IllegalStateException(
                    "Age range overlaps with existing age group"
            );
        }

        Age age= AgeConverter.toEntity(vo);

        return AgeConverter.toResponse(ageRepo.save(age));
    }

    @Override
    @Transactional
    public AgeResponseVO update(Long id, AgeRequestVO vo) {
        Age age=ageFetcher.getById(id);

        // ✅ Update label only if provided
        if (vo.getLabel() != null && !vo.getLabel().isBlank()) {
            age.setLabel(vo.getLabel());
        }

        // ✅ Update minAge only if provided
        if (vo.getMinAge() != null) {
            age.setMinAge(vo.getMinAge());
        }

        // ✅ Update maxAge only if provided
        if (vo.getMaxAge() != null) {
            age.setMaxAge(vo.getMaxAge());
        }

        // ✅ Optional business validation (recommended)
        if (age.getMinAge() > age.getMaxAge()) {
            throw new ResourceNotFoundException(
                    "minAge cannot be greater than maxAge"
            );
        }

        return AgeConverter.toResponse(ageRepo.save(age));
    }

    @Override
    public AgeResponseVO getById(Long id) {
        return AgeConverter.toResponse(
            ageFetcher.getById(id)
        );
    }

    @Override
    @Transactional
    public void deleteById(Long id) {
        Age age=ageFetcher.getById(id);
        ageRepo.delete(age);
    }

    @Override
    public List<AgeResponseVO> getAll() {
        return ageRepo.findAll()
                .stream()
                .map(AgeConverter::toResponse)
                .toList();
    }
}
