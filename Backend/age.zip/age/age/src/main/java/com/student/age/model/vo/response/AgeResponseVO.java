package com.student.age.model.vo.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AgeResponseVO {

    private Long id;
    private String label;
    private Integer minAge;
    private Integer maxAge;
}
