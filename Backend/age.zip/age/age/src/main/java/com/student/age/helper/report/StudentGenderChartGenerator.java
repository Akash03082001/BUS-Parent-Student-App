package com.student.age.helper.report;

import com.student.age.model.vo.response.StudentSearchCriteriaResponseVO;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

import java.io.ByteArrayOutputStream;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StudentGenderChartGenerator {

    // ✅ Gender Pie Chart
    public static byte[] generateGenderPieChart(
            List<StudentSearchCriteriaResponseVO> students) {

        Map<String, Long> genderCount =
                students.stream()
                        .collect(Collectors.groupingBy(
                                StudentSearchCriteriaResponseVO::getGender,
                                Collectors.counting()
                        ));

        DefaultPieDataset dataset = new DefaultPieDataset();
        genderCount.forEach(dataset::setValue);

        JFreeChart chart = ChartFactory.createPieChart(
                "Students by Gender",
                dataset,
                true,
                true,
                false
        );


        // ✅ Customize labels
        PiePlot plot = (PiePlot) chart.getPlot();
        plot.setLabelGenerator(
                new StandardPieSectionLabelGenerator(
                        "{0} ({1} - {2})",       // {0}=Label, {1}=Count
                        new DecimalFormat("0"),
                        new DecimalFormat("0%")
                )
        );


        return chartToImage(chart);
    }

    private static byte[] chartToImage(JFreeChart chart) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ChartUtils.writeChartAsPNG(out, chart, 500, 300);
            return out.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Chart generation failed", e);
        }
    }

}
