package com.student.age.helper.converter;

import com.student.age.model.entity.Age;
import com.student.age.model.vo.request.AgeRequestVO;
import com.student.age.model.vo.response.AgeResponseVO;
import org.springframework.stereotype.Component;

public class AgeConverter {

    public static Age toEntity(AgeRequestVO vo){
        Age age=new Age();
        age.setLabel(vo.getLabel());
        age.setMinAge(vo.getMinAge());
        age.setMaxAge(vo.getMaxAge());

        return age;
    }

    public static AgeResponseVO toResponse(Age entity){
        AgeResponseVO ageResponseVO=new AgeResponseVO();
        if(entity==null)
            return null;
        ageResponseVO.setId(entity.getId());
        ageResponseVO.setLabel(entity.getLabel());
        ageResponseVO.setMinAge(entity.getMinAge());
        ageResponseVO.setMaxAge(entity.getMaxAge());

        return ageResponseVO;
    }
}
