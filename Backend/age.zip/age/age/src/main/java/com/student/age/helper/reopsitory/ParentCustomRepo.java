package com.student.age.helper.reopsitory;

import com.student.age.model.entity.AccountStatus;
import com.student.age.model.entity.Parent;

import java.util.List;

public interface ParentCustomRepo {
    List<Parent> searchParents(String name, String email, AccountStatus status);
}
