package com.student.age.controller.frontEnd;

import com.student.age.config.JwtUtil;
import com.student.age.helper.reopsitory.StudentRepo;
import com.student.age.model.frontend.ViewStudentResponse;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/parent/students")
@RequiredArgsConstructor
@CrossOrigin(
        origins = "http://localhost:4200",
        allowedHeaders = "*",
        methods = { RequestMethod.GET, RequestMethod.OPTIONS }
)
public class ViewStudentsController {

    private final JwtUtil jwtUtil;
    private final StudentRepo studentRepo;

    @GetMapping
    public List<ViewStudentResponse> getStudents(HttpServletRequest request){
        Long parentId = jwtUtil.extractParentId(request);

        return studentRepo.findByParentIdWithAgeGroup(parentId)
                .stream()
                .map(s->new ViewStudentResponse(

                        s.getId(),
                        s.getName(),
                        s.getGender(),
                        s.getAge(),
                        s.getDateOfBirth(),
                        s.getAgeDetails().getLabel()

                )).toList();
    }

}
