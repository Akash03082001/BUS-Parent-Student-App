package com.student.age.model.entity;

public enum AccountStatus {
    ACTIVE,INACTIVE,DELETED
}
