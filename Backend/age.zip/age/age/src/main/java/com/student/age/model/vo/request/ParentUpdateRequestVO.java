package com.student.age.model.vo.request;

import jakarta.validation.constraints.Email;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class ParentUpdateRequestVO {
    private String name;

    @Email(message = "Invalid email format")
    private String email;
}
//why we created another request class for parent update, because the parent has
//email and that email is unique and not null so we used two different class for
//update. One class for email and other class for details
