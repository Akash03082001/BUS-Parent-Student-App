package com.student.age.model.frontend;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class AddStudentRequest {

    @NotBlank
    private String name;

    @NotBlank
    private String gender;

    @NotNull
    @Past
    private LocalDate dateOfBirth;
}