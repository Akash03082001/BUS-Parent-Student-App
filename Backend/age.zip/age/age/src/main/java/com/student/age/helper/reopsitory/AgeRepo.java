package com.student.age.helper.reopsitory;

import com.student.age.model.entity.Age;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface AgeRepo extends JpaRepository<Age,Long> {

    //Checks duplicate labels
    boolean existsByLabelIgnoreCase(String label);

    //Detects overlapping age ranges
    boolean existsByMinAgeLessThanEqualAndMaxAgeGreaterThanEqual(
            Integer maxAge, Integer minAge
    );

    Optional<Object> findByMinAgeLessThanEqualAndMaxAgeGreaterThanEqual(Integer age, Integer age1);
}
