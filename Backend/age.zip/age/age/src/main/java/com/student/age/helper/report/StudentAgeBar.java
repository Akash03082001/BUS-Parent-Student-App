package com.student.age.helper.report;

import com.student.age.model.vo.response.StudentSearchCriteriaResponseVO;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

import java.awt.*;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StudentAgeBar {

    public static byte[] generateAgeBarChart(
            List<StudentSearchCriteriaResponseVO> students) {

        // Group students by age
        Map<Integer, Long> ageCount =
                students.stream()
                        .collect(Collectors.groupingBy(
                                StudentSearchCriteriaResponseVO::getAge,
                                Collectors.counting()
                        ));

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        ageCount.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .forEach(entry ->
                        dataset.addValue(
                                entry.getValue(),
                                "Students",
                                entry.getKey()
                        )
                );

        JFreeChart chart = ChartFactory.createBarChart(
                "Students by Age",
                "Age",
                "Number of Students",
                dataset
        );

        // Styling
        CategoryPlot plot = chart.getCategoryPlot();
        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, new Color(79, 129, 189));

        // IMPORTANT: Do NOT show labels on bars
        renderer.setDefaultItemLabelsVisible(false);

        // Fonts
        chart.getTitle().setFont(new Font("SansSerif", Font.BOLD, 20));
        plot.getDomainAxis().setLabelFont(new Font("SansSerif", Font.BOLD, 16));
        plot.getRangeAxis().setLabelFont(new Font("SansSerif", Font.BOLD, 16));
        plot.getDomainAxis().setTickLabelFont(new Font("SansSerif", Font.PLAIN, 14));
        plot.getRangeAxis().setTickLabelFont(new Font("SansSerif", Font.PLAIN, 14));

        return chartToImage(chart);
    }

    private static byte[] chartToImage(JFreeChart chart) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ChartUtils.writeChartAsPNG(out, chart, 900, 500);
            return out.toByteArray();
        } catch (Exception e) {
            throw new RuntimeException("Age Bar Chart generation failed", e);
        }
    }
}
